package java.beans;

import java.util.EventListener;

public abstract interface PropertyChangeListener extends EventListener
{
  public abstract void propertyChange(PropertyChangeEvent paramPropertyChangeEvent);
}

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.beans.PropertyChangeListener
 * JD-Core Version:    0.6.0
 */