/*   */ package java.beans;
/*   */ 
/*   */ public class IndexedPropertyChangeEvent extends PropertyChangeEvent
/*   */ {
/*   */   public IndexedPropertyChangeEvent(Object source, String propertyName, Object oldValue, Object newValue, int index)
/*   */   {
/* 5 */     super((Object)null, (String)null, (Object)null, (Object)null); throw new RuntimeException("Stub!"); } 
/* 6 */   public int getIndex() { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.beans.IndexedPropertyChangeEvent
 * JD-Core Version:    0.6.0
 */