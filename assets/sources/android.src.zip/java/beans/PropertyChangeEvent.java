/*    */ package java.beans;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ 
/*    */ public class PropertyChangeEvent extends EventObject
/*    */ {
/*    */   public PropertyChangeEvent(Object source, String propertyName, Object oldValue, Object newValue)
/*    */   {
/*  5 */     super((Object)null); throw new RuntimeException("Stub!"); } 
/*  6 */   public String getPropertyName() { throw new RuntimeException("Stub!"); } 
/*  7 */   public void setPropagationId(Object propagationId) { throw new RuntimeException("Stub!"); } 
/*  8 */   public Object getPropagationId() { throw new RuntimeException("Stub!"); } 
/*  9 */   public Object getOldValue() { throw new RuntimeException("Stub!"); } 
/* 10 */   public Object getNewValue() { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.beans.PropertyChangeEvent
 * JD-Core Version:    0.6.0
 */