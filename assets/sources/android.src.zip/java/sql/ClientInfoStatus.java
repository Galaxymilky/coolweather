/*   */ package java.sql;
/*   */ 
/*   */ public enum ClientInfoStatus
/*   */ {
/* 4 */   REASON_UNKNOWN, 
/* 5 */   REASON_UNKNOWN_PROPERTY, 
/* 6 */   REASON_VALUE_INVALID, 
/* 7 */   REASON_VALUE_TRUNCATED;
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.sql.ClientInfoStatus
 * JD-Core Version:    0.6.0
 */