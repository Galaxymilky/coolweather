/*    */ package java.sql;
/*    */ 
/*    */ public class SQLDataException extends SQLNonTransientException
/*    */ {
/*    */   public SQLDataException()
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public SQLDataException(String reason) { throw new RuntimeException("Stub!"); } 
/*  7 */   public SQLDataException(String reason, String sqlState) { throw new RuntimeException("Stub!"); } 
/*  8 */   public SQLDataException(String reason, String sqlState, int vendorCode) { throw new RuntimeException("Stub!"); } 
/*  9 */   public SQLDataException(Throwable cause) { throw new RuntimeException("Stub!"); } 
/* 10 */   public SQLDataException(String reason, Throwable cause) { throw new RuntimeException("Stub!"); } 
/* 11 */   public SQLDataException(String reason, String sqlState, Throwable cause) { throw new RuntimeException("Stub!"); } 
/* 12 */   public SQLDataException(String reason, String sqlState, int vendorCode, Throwable cause) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.sql.SQLDataException
 * JD-Core Version:    0.6.0
 */