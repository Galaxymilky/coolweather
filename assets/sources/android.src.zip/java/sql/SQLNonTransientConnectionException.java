/*    */ package java.sql;
/*    */ 
/*    */ public class SQLNonTransientConnectionException extends SQLNonTransientException
/*    */ {
/*    */   public SQLNonTransientConnectionException()
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public SQLNonTransientConnectionException(String reason) { throw new RuntimeException("Stub!"); } 
/*  7 */   public SQLNonTransientConnectionException(String reason, String sqlState) { throw new RuntimeException("Stub!"); } 
/*  8 */   public SQLNonTransientConnectionException(String reason, String sqlState, int vendorCode) { throw new RuntimeException("Stub!"); } 
/*  9 */   public SQLNonTransientConnectionException(Throwable cause) { throw new RuntimeException("Stub!"); } 
/* 10 */   public SQLNonTransientConnectionException(String reason, Throwable cause) { throw new RuntimeException("Stub!"); } 
/* 11 */   public SQLNonTransientConnectionException(String reason, String sqlState, Throwable cause) { throw new RuntimeException("Stub!"); } 
/* 12 */   public SQLNonTransientConnectionException(String reason, String sqlState, int vendorCode, Throwable cause) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.sql.SQLNonTransientConnectionException
 * JD-Core Version:    0.6.0
 */