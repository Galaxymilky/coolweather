/*    */ package java.sql;
/*    */ 
/*    */ import java.util.Date;
/*    */ 
/*    */ public class Time extends Date
/*    */ {
/*    */   @Deprecated
/*    */   public Time(int theHour, int theMinute, int theSecond)
/*    */   {
/*  7 */     throw new RuntimeException("Stub!"); } 
/*  8 */   public Time(long theTime) { throw new RuntimeException("Stub!"); } 
/* 11 */   @Deprecated
/*    */   public int getDate() { throw new RuntimeException("Stub!"); } 
/* 14 */   @Deprecated
/*    */   public int getDay() { throw new RuntimeException("Stub!"); } 
/* 17 */   @Deprecated
/*    */   public int getMonth() { throw new RuntimeException("Stub!"); } 
/* 20 */   @Deprecated
/*    */   public int getYear() { throw new RuntimeException("Stub!"); } 
/* 23 */   @Deprecated
/*    */   public void setDate(int i) { throw new RuntimeException("Stub!"); } 
/* 26 */   @Deprecated
/*    */   public void setMonth(int i) { throw new RuntimeException("Stub!"); } 
/* 29 */   @Deprecated
/*    */   public void setYear(int i) { throw new RuntimeException("Stub!"); } 
/* 30 */   public void setTime(long time) { throw new RuntimeException("Stub!"); } 
/* 31 */   public String toString() { throw new RuntimeException("Stub!"); } 
/* 32 */   public static Time valueOf(String timeString) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.sql.Time
 * JD-Core Version:    0.6.0
 */