/*    */ package java.sql;
/*    */ 
/*    */ public class SQLFeatureNotSupportedException extends SQLNonTransientException
/*    */ {
/*    */   public SQLFeatureNotSupportedException()
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public SQLFeatureNotSupportedException(String reason) { throw new RuntimeException("Stub!"); } 
/*  7 */   public SQLFeatureNotSupportedException(String reason, String sqlState) { throw new RuntimeException("Stub!"); } 
/*  8 */   public SQLFeatureNotSupportedException(String reason, String sqlState, int vendorCode) { throw new RuntimeException("Stub!"); } 
/*  9 */   public SQLFeatureNotSupportedException(Throwable cause) { throw new RuntimeException("Stub!"); } 
/* 10 */   public SQLFeatureNotSupportedException(String reason, Throwable cause) { throw new RuntimeException("Stub!"); } 
/* 11 */   public SQLFeatureNotSupportedException(String reason, String sqlState, Throwable cause) { throw new RuntimeException("Stub!"); } 
/* 12 */   public SQLFeatureNotSupportedException(String reason, String sqlState, int vendorCode, Throwable cause) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.sql.SQLFeatureNotSupportedException
 * JD-Core Version:    0.6.0
 */