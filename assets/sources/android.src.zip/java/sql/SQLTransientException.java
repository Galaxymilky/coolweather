/*    */ package java.sql;
/*    */ 
/*    */ public class SQLTransientException extends SQLException
/*    */ {
/*    */   public SQLTransientException()
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public SQLTransientException(String reason) { throw new RuntimeException("Stub!"); } 
/*  7 */   public SQLTransientException(String reason, String sqlState) { throw new RuntimeException("Stub!"); } 
/*  8 */   public SQLTransientException(String reason, String sqlState, int vendorCode) { throw new RuntimeException("Stub!"); } 
/*  9 */   public SQLTransientException(Throwable cause) { throw new RuntimeException("Stub!"); } 
/* 10 */   public SQLTransientException(String reason, Throwable cause) { throw new RuntimeException("Stub!"); } 
/* 11 */   public SQLTransientException(String reason, String sqlState, Throwable cause) { throw new RuntimeException("Stub!"); } 
/* 12 */   public SQLTransientException(String reason, String sqlState, int vendorCode, Throwable cause) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.sql.SQLTransientException
 * JD-Core Version:    0.6.0
 */