package java.sql;

public abstract interface NClob extends Clob
{
}

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.sql.NClob
 * JD-Core Version:    0.6.0
 */