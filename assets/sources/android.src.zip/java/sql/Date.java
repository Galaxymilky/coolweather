/*    */ package java.sql;
/*    */ 
/*    */ public class Date extends java.util.Date
/*    */ {
/*    */   @Deprecated
/*    */   public Date(int theYear, int theMonth, int theDay)
/*    */   {
/*  6 */     throw new RuntimeException("Stub!"); } 
/*  7 */   public Date(long theDate) { throw new RuntimeException("Stub!"); } 
/*  9 */   @Deprecated
/*    */   public int getHours() { throw new RuntimeException("Stub!"); } 
/* 11 */   @Deprecated
/*    */   public int getMinutes() { throw new RuntimeException("Stub!"); } 
/* 13 */   @Deprecated
/*    */   public int getSeconds() { throw new RuntimeException("Stub!"); } 
/* 15 */   @Deprecated
/*    */   public void setHours(int theHours) { throw new RuntimeException("Stub!"); } 
/* 17 */   @Deprecated
/*    */   public void setMinutes(int theMinutes) { throw new RuntimeException("Stub!"); } 
/* 19 */   @Deprecated
/*    */   public void setSeconds(int theSeconds) { throw new RuntimeException("Stub!"); } 
/* 20 */   public void setTime(long theTime) { throw new RuntimeException("Stub!"); } 
/* 21 */   public String toString() { throw new RuntimeException("Stub!"); } 
/* 22 */   public static Date valueOf(String dateString) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.sql.Date
 * JD-Core Version:    0.6.0
 */