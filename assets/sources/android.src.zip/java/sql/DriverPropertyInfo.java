/*   */ package java.sql;
/*   */ 
/*   */ public class DriverPropertyInfo
/*   */ {
/* 5 */   public String[] choices = null;
/*   */   public String description;
/*   */   public String name;
/*   */   public boolean required;
/*   */   public String value;
/*   */ 
/*   */   public DriverPropertyInfo(String name, String value)
/*   */   {
/* 4 */     throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.sql.DriverPropertyInfo
 * JD-Core Version:    0.6.0
 */