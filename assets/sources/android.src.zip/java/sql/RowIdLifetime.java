/*   */ package java.sql;
/*   */ 
/*   */ public enum RowIdLifetime
/*   */ {
/* 4 */   ROWID_UNSUPPORTED, 
/* 5 */   ROWID_VALID_FOREVER, 
/* 6 */   ROWID_VALID_OTHER, 
/* 7 */   ROWID_VALID_SESSION, 
/* 8 */   ROWID_VALID_TRANSACTION;
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.sql.RowIdLifetime
 * JD-Core Version:    0.6.0
 */