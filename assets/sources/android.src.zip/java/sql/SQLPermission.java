/*   */ package java.sql;
/*   */ 
/*   */ import java.io.Serializable;
/*   */ import java.security.BasicPermission;
/*   */ import java.security.Guard;
/*   */ import java.security.Permission;
/*   */ 
/*   */ public final class SQLPermission extends BasicPermission
/*   */   implements Guard, Serializable
/*   */ {
/*   */   public SQLPermission(String name)
/*   */   {
/* 6 */     super((String)null, (String)null); throw new RuntimeException("Stub!"); } 
/* 7 */   public SQLPermission(String name, String actions) { super((String)null, (String)null); throw new RuntimeException("Stub!"); } 
/* 8 */   public String getActions() { throw new RuntimeException("Stub!"); } 
/* 9 */   public boolean implies(Permission permission) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.sql.SQLPermission
 * JD-Core Version:    0.6.0
 */