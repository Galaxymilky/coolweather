/*    */ package java.sql;
/*    */ 
/*    */ import java.util.Date;
/*    */ 
/*    */ public class Timestamp extends Date
/*    */ {
/*    */   @Deprecated
/*    */   public Timestamp(int theYear, int theMonth, int theDate, int theHour, int theMinute, int theSecond, int theNano)
/*    */     throws IllegalArgumentException
/*    */   {
/*  7 */     throw new RuntimeException("Stub!"); } 
/*  8 */   public Timestamp(long theTime) { throw new RuntimeException("Stub!"); } 
/*  9 */   public boolean after(Timestamp theTimestamp) { throw new RuntimeException("Stub!"); } 
/* 10 */   public boolean before(Timestamp theTimestamp) { throw new RuntimeException("Stub!"); } 
/* 11 */   public int compareTo(Date theObject) throws ClassCastException { throw new RuntimeException("Stub!"); } 
/* 12 */   public int compareTo(Timestamp theTimestamp) { throw new RuntimeException("Stub!"); } 
/* 13 */   public boolean equals(Object theObject) { throw new RuntimeException("Stub!"); } 
/* 14 */   public boolean equals(Timestamp theTimestamp) { throw new RuntimeException("Stub!"); } 
/* 15 */   public int getNanos() { throw new RuntimeException("Stub!"); } 
/* 16 */   public long getTime() { throw new RuntimeException("Stub!"); } 
/* 17 */   public void setNanos(int n) throws IllegalArgumentException { throw new RuntimeException("Stub!"); } 
/* 18 */   public void setTime(long theTime) { throw new RuntimeException("Stub!"); } 
/*    */   public String toString() {
/* 20 */     throw new RuntimeException("Stub!"); } 
/* 21 */   public static Timestamp valueOf(String s) throws IllegalArgumentException { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.sql.Timestamp
 * JD-Core Version:    0.6.0
 */