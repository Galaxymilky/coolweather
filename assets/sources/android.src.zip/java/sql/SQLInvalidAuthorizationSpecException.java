/*    */ package java.sql;
/*    */ 
/*    */ public class SQLInvalidAuthorizationSpecException extends SQLNonTransientException
/*    */ {
/*    */   public SQLInvalidAuthorizationSpecException()
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public SQLInvalidAuthorizationSpecException(String reason) { throw new RuntimeException("Stub!"); } 
/*  7 */   public SQLInvalidAuthorizationSpecException(String reason, String sqlState) { throw new RuntimeException("Stub!"); } 
/*  8 */   public SQLInvalidAuthorizationSpecException(String reason, String sqlState, int vendorCode) { throw new RuntimeException("Stub!"); } 
/*  9 */   public SQLInvalidAuthorizationSpecException(Throwable cause) { throw new RuntimeException("Stub!"); } 
/* 10 */   public SQLInvalidAuthorizationSpecException(String reason, Throwable cause) { throw new RuntimeException("Stub!"); } 
/* 11 */   public SQLInvalidAuthorizationSpecException(String reason, String sqlState, Throwable cause) { throw new RuntimeException("Stub!"); } 
/* 12 */   public SQLInvalidAuthorizationSpecException(String reason, String sqlState, int vendorCode, Throwable cause) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.sql.SQLInvalidAuthorizationSpecException
 * JD-Core Version:    0.6.0
 */