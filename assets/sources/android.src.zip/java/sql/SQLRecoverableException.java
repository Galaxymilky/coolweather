/*    */ package java.sql;
/*    */ 
/*    */ public class SQLRecoverableException extends SQLException
/*    */ {
/*    */   public SQLRecoverableException()
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public SQLRecoverableException(String reason) { throw new RuntimeException("Stub!"); } 
/*  7 */   public SQLRecoverableException(String reason, String sqlState) { throw new RuntimeException("Stub!"); } 
/*  8 */   public SQLRecoverableException(String reason, String sqlState, int vendorCode) { throw new RuntimeException("Stub!"); } 
/*  9 */   public SQLRecoverableException(Throwable cause) { throw new RuntimeException("Stub!"); } 
/* 10 */   public SQLRecoverableException(String reason, Throwable cause) { throw new RuntimeException("Stub!"); } 
/* 11 */   public SQLRecoverableException(String reason, String sqlState, Throwable cause) { throw new RuntimeException("Stub!"); } 
/* 12 */   public SQLRecoverableException(String reason, String sqlState, int vendorCode, Throwable cause) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.sql.SQLRecoverableException
 * JD-Core Version:    0.6.0
 */