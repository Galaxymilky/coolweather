/*    */ package java.text;
/*    */ 
/*    */ public class FieldPosition
/*    */ {
/*    */   public FieldPosition(int field)
/*    */   {
/*  4 */     throw new RuntimeException("Stub!"); } 
/*  5 */   public FieldPosition(Format.Field attribute) { throw new RuntimeException("Stub!"); } 
/*  6 */   public FieldPosition(Format.Field attribute, int field) { throw new RuntimeException("Stub!"); } 
/*  7 */   public boolean equals(Object object) { throw new RuntimeException("Stub!"); } 
/*  8 */   public int getBeginIndex() { throw new RuntimeException("Stub!"); } 
/*  9 */   public int getEndIndex() { throw new RuntimeException("Stub!"); } 
/* 10 */   public int getField() { throw new RuntimeException("Stub!"); } 
/* 11 */   public Format.Field getFieldAttribute() { throw new RuntimeException("Stub!"); } 
/* 12 */   public int hashCode() { throw new RuntimeException("Stub!"); } 
/* 13 */   public void setBeginIndex(int index) { throw new RuntimeException("Stub!"); } 
/* 14 */   public void setEndIndex(int index) { throw new RuntimeException("Stub!"); } 
/* 15 */   public String toString() { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.text.FieldPosition
 * JD-Core Version:    0.6.0
 */