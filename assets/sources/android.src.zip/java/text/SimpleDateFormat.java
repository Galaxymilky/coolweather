/*    */ package java.text;
/*    */ 
/*    */ import java.util.Date;
/*    */ import java.util.Locale;
/*    */ 
/*    */ public class SimpleDateFormat extends DateFormat
/*    */ {
/*    */   public SimpleDateFormat()
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public SimpleDateFormat(String pattern) { throw new RuntimeException("Stub!"); } 
/*  7 */   public SimpleDateFormat(String template, DateFormatSymbols value) { throw new RuntimeException("Stub!"); } 
/*  8 */   public SimpleDateFormat(String template, Locale locale) { throw new RuntimeException("Stub!"); } 
/*  9 */   public void applyLocalizedPattern(String template) { throw new RuntimeException("Stub!"); } 
/* 10 */   public void applyPattern(String template) { throw new RuntimeException("Stub!"); } 
/* 11 */   public Object clone() { throw new RuntimeException("Stub!"); } 
/* 12 */   public boolean equals(Object object) { throw new RuntimeException("Stub!"); } 
/* 13 */   public AttributedCharacterIterator formatToCharacterIterator(Object object) { throw new RuntimeException("Stub!"); } 
/* 14 */   public StringBuffer format(Date date, StringBuffer buffer, FieldPosition fieldPos) { throw new RuntimeException("Stub!"); } 
/* 15 */   public Date get2DigitYearStart() { throw new RuntimeException("Stub!"); } 
/* 16 */   public DateFormatSymbols getDateFormatSymbols() { throw new RuntimeException("Stub!"); } 
/* 17 */   public int hashCode() { throw new RuntimeException("Stub!"); } 
/* 18 */   public Date parse(String string, ParsePosition position) { throw new RuntimeException("Stub!"); } 
/* 19 */   public void set2DigitYearStart(Date date) { throw new RuntimeException("Stub!"); } 
/* 20 */   public void setDateFormatSymbols(DateFormatSymbols value) { throw new RuntimeException("Stub!"); } 
/* 21 */   public String toLocalizedPattern() { throw new RuntimeException("Stub!"); } 
/* 22 */   public String toPattern() { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.text.SimpleDateFormat
 * JD-Core Version:    0.6.0
 */