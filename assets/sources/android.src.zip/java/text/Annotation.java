/*   */ package java.text;
/*   */ 
/*   */ public class Annotation
/*   */ {
/*   */   public Annotation(Object attribute)
/*   */   {
/* 4 */     throw new RuntimeException("Stub!"); } 
/* 5 */   public Object getValue() { throw new RuntimeException("Stub!"); } 
/* 6 */   public String toString() { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.text.Annotation
 * JD-Core Version:    0.6.0
 */