/*   */ package java.text;
/*   */ 
/*   */ public class ParseException extends Exception
/*   */ {
/*   */   public ParseException(String detailMessage, int location)
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public int getErrorOffset() { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.text.ParseException
 * JD-Core Version:    0.6.0
 */