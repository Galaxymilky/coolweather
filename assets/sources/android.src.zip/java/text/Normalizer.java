/*    */ package java.text;
/*    */ 
/*    */ public final class Normalizer
/*    */ {
/*    */   Normalizer()
/*    */   {
/* 11 */     throw new RuntimeException("Stub!"); } 
/* 12 */   public static boolean isNormalized(CharSequence src, Form form) { throw new RuntimeException("Stub!"); } 
/* 13 */   public static String normalize(CharSequence src, Form form) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ 
/*    */   public static enum Form
/*    */   {
/*  6 */     NFC, 
/*  7 */     NFD, 
/*  8 */     NFKC, 
/*  9 */     NFKD;
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.text.Normalizer
 * JD-Core Version:    0.6.0
 */