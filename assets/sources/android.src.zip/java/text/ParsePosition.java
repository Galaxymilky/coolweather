/*    */ package java.text;
/*    */ 
/*    */ public class ParsePosition
/*    */ {
/*    */   public ParsePosition(int index)
/*    */   {
/*  4 */     throw new RuntimeException("Stub!"); } 
/*  5 */   public boolean equals(Object object) { throw new RuntimeException("Stub!"); } 
/*  6 */   public int getErrorIndex() { throw new RuntimeException("Stub!"); } 
/*  7 */   public int getIndex() { throw new RuntimeException("Stub!"); } 
/*  8 */   public int hashCode() { throw new RuntimeException("Stub!"); } 
/*  9 */   public void setErrorIndex(int index) { throw new RuntimeException("Stub!"); } 
/* 10 */   public void setIndex(int index) { throw new RuntimeException("Stub!"); } 
/* 11 */   public String toString() { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.text.ParsePosition
 * JD-Core Version:    0.6.0
 */