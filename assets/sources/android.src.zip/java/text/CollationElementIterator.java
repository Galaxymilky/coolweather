/*    */ package java.text;
/*    */ 
/*    */ public final class CollationElementIterator
/*    */ {
/*    */   public static final int NULLORDER = -1;
/*    */ 
/*    */   CollationElementIterator()
/*    */   {
/*  4 */     throw new RuntimeException("Stub!"); } 
/*  5 */   public int getMaxExpansion(int order) { throw new RuntimeException("Stub!"); } 
/*  6 */   public int getOffset() { throw new RuntimeException("Stub!"); } 
/*  7 */   public int next() { throw new RuntimeException("Stub!"); } 
/*  8 */   public int previous() { throw new RuntimeException("Stub!"); } 
/*  9 */   public static final int primaryOrder(int order) { throw new RuntimeException("Stub!"); } 
/* 10 */   public void reset() { throw new RuntimeException("Stub!"); } 
/* 11 */   public static final short secondaryOrder(int order) { throw new RuntimeException("Stub!"); } 
/* 12 */   public void setOffset(int newOffset) { throw new RuntimeException("Stub!"); } 
/* 13 */   public void setText(CharacterIterator source) { throw new RuntimeException("Stub!"); } 
/* 14 */   public void setText(String source) { throw new RuntimeException("Stub!"); } 
/* 15 */   public static final short tertiaryOrder(int order) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.text.CollationElementIterator
 * JD-Core Version:    0.6.0
 */