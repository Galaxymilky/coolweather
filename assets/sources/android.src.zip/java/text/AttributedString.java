/*    */ package java.text;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ public class AttributedString
/*    */ {
/*    */   public AttributedString(AttributedCharacterIterator iterator)
/*    */   {
/*  4 */     throw new RuntimeException("Stub!"); } 
/*  5 */   public AttributedString(AttributedCharacterIterator iterator, int start, int end) { throw new RuntimeException("Stub!"); } 
/*  6 */   public AttributedString(AttributedCharacterIterator iterator, int start, int end, AttributedCharacterIterator.Attribute[] attributes) { throw new RuntimeException("Stub!"); } 
/*  7 */   public AttributedString(String value) { throw new RuntimeException("Stub!"); } 
/*  8 */   public AttributedString(String value, Map<? extends AttributedCharacterIterator.Attribute, ?> attributes) { throw new RuntimeException("Stub!"); } 
/*  9 */   public void addAttribute(AttributedCharacterIterator.Attribute attribute, Object value) { throw new RuntimeException("Stub!"); } 
/* 10 */   public void addAttribute(AttributedCharacterIterator.Attribute attribute, Object value, int start, int end) { throw new RuntimeException("Stub!"); } 
/* 11 */   public void addAttributes(Map<? extends AttributedCharacterIterator.Attribute, ?> attributes, int start, int end) { throw new RuntimeException("Stub!"); } 
/* 12 */   public AttributedCharacterIterator getIterator() { throw new RuntimeException("Stub!"); } 
/* 13 */   public AttributedCharacterIterator getIterator(AttributedCharacterIterator.Attribute[] attributes) { throw new RuntimeException("Stub!"); } 
/* 14 */   public AttributedCharacterIterator getIterator(AttributedCharacterIterator.Attribute[] attributes, int start, int end) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.text.AttributedString
 * JD-Core Version:    0.6.0
 */