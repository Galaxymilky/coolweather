/*    */ package java.text;
/*    */ 
/*    */ public class ChoiceFormat extends NumberFormat
/*    */ {
/*    */   public ChoiceFormat(double[] limits, String[] formats)
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public ChoiceFormat(String template) { throw new RuntimeException("Stub!"); } 
/*  7 */   public void applyPattern(String template) { throw new RuntimeException("Stub!"); } 
/*  8 */   public Object clone() { throw new RuntimeException("Stub!"); } 
/*  9 */   public boolean equals(Object object) { throw new RuntimeException("Stub!"); } 
/* 10 */   public StringBuffer format(double value, StringBuffer buffer, FieldPosition field) { throw new RuntimeException("Stub!"); } 
/* 11 */   public StringBuffer format(long value, StringBuffer buffer, FieldPosition field) { throw new RuntimeException("Stub!"); } 
/* 12 */   public Object[] getFormats() { throw new RuntimeException("Stub!"); } 
/* 13 */   public double[] getLimits() { throw new RuntimeException("Stub!"); } 
/* 14 */   public int hashCode() { throw new RuntimeException("Stub!"); } 
/* 15 */   public static final double nextDouble(double value) { throw new RuntimeException("Stub!"); } 
/* 16 */   public static double nextDouble(double value, boolean increment) { throw new RuntimeException("Stub!"); } 
/* 17 */   public Number parse(String string, ParsePosition position) { throw new RuntimeException("Stub!"); } 
/* 18 */   public static final double previousDouble(double value) { throw new RuntimeException("Stub!"); } 
/* 19 */   public void setChoices(double[] limits, String[] formats) { throw new RuntimeException("Stub!"); } 
/* 20 */   public String toPattern() { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.text.ChoiceFormat
 * JD-Core Version:    0.6.0
 */