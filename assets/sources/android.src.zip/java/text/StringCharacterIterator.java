/*    */ package java.text;
/*    */ 
/*    */ public final class StringCharacterIterator
/*    */   implements CharacterIterator
/*    */ {
/*    */   public StringCharacterIterator(String value)
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public StringCharacterIterator(String value, int location) { throw new RuntimeException("Stub!"); } 
/*  7 */   public StringCharacterIterator(String value, int start, int end, int location) { throw new RuntimeException("Stub!"); } 
/*  8 */   public Object clone() { throw new RuntimeException("Stub!"); } 
/*  9 */   public char current() { throw new RuntimeException("Stub!"); } 
/* 10 */   public boolean equals(Object object) { throw new RuntimeException("Stub!"); } 
/* 11 */   public char first() { throw new RuntimeException("Stub!"); } 
/* 12 */   public int getBeginIndex() { throw new RuntimeException("Stub!"); } 
/* 13 */   public int getEndIndex() { throw new RuntimeException("Stub!"); } 
/* 14 */   public int getIndex() { throw new RuntimeException("Stub!"); } 
/* 15 */   public int hashCode() { throw new RuntimeException("Stub!"); } 
/* 16 */   public char last() { throw new RuntimeException("Stub!"); } 
/* 17 */   public char next() { throw new RuntimeException("Stub!"); } 
/* 18 */   public char previous() { throw new RuntimeException("Stub!"); } 
/* 19 */   public char setIndex(int location) { throw new RuntimeException("Stub!"); } 
/* 20 */   public void setText(String value) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.text.StringCharacterIterator
 * JD-Core Version:    0.6.0
 */