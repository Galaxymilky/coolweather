/*    */ package java.text;
/*    */ 
/*    */ public class RuleBasedCollator extends Collator
/*    */ {
/*    */   public RuleBasedCollator(String rules)
/*    */     throws ParseException
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public CollationElementIterator getCollationElementIterator(CharacterIterator source) { throw new RuntimeException("Stub!"); } 
/*  7 */   public CollationElementIterator getCollationElementIterator(String source) { throw new RuntimeException("Stub!"); } 
/*  8 */   public String getRules() { throw new RuntimeException("Stub!"); } 
/*  9 */   public Object clone() { throw new RuntimeException("Stub!"); } 
/* 10 */   public int compare(String source, String target) { throw new RuntimeException("Stub!"); } 
/* 11 */   public CollationKey getCollationKey(String source) { throw new RuntimeException("Stub!"); } 
/* 12 */   public int hashCode() { throw new RuntimeException("Stub!"); } 
/* 13 */   public boolean equals(Object obj) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.text.RuleBasedCollator
 * JD-Core Version:    0.6.0
 */