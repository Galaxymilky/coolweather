/*   */ package java.text;
/*   */ 
/*   */ public abstract class CollationKey
/*   */   implements Comparable<CollationKey>
/*   */ {
/*   */   protected CollationKey(String source)
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/*   */   public abstract int compareTo(CollationKey paramCollationKey);
/*   */ 
/* 7 */   public String getSourceString() { throw new RuntimeException("Stub!");
/*   */   }
/*   */ 
/*   */   public abstract byte[] toByteArray();
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.text.CollationKey
 * JD-Core Version:    0.6.0
 */