/*   */ package java.util;
/*   */ 
/*   */ public class MissingResourceException extends RuntimeException
/*   */ {
/*   */   public MissingResourceException(String detailMessage, String className, String resourceName)
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public String getClassName() { throw new RuntimeException("Stub!"); } 
/* 7 */   public String getKey() { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.MissingResourceException
 * JD-Core Version:    0.6.0
 */