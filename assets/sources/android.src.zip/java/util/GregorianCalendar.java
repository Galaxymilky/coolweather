/*    */ package java.util;
/*    */ 
/*    */ public class GregorianCalendar extends Calendar
/*    */ {
/*    */   public static final int BC = 0;
/*    */   public static final int AD = 1;
/*    */ 
/*    */   public GregorianCalendar()
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public GregorianCalendar(int year, int month, int day) { throw new RuntimeException("Stub!"); } 
/*  7 */   public GregorianCalendar(int year, int month, int day, int hour, int minute) { throw new RuntimeException("Stub!"); } 
/*  8 */   public GregorianCalendar(int year, int month, int day, int hour, int minute, int second) { throw new RuntimeException("Stub!"); } 
/*  9 */   public GregorianCalendar(Locale locale) { throw new RuntimeException("Stub!"); } 
/* 10 */   public GregorianCalendar(TimeZone timezone) { throw new RuntimeException("Stub!"); } 
/* 11 */   public GregorianCalendar(TimeZone timezone, Locale locale) { throw new RuntimeException("Stub!"); } 
/* 12 */   public void add(int field, int value) { throw new RuntimeException("Stub!"); } 
/* 13 */   public Object clone() { throw new RuntimeException("Stub!"); } 
/* 14 */   protected void computeFields() { throw new RuntimeException("Stub!"); } 
/* 15 */   protected void computeTime() { throw new RuntimeException("Stub!"); } 
/* 16 */   public boolean equals(Object object) { throw new RuntimeException("Stub!"); } 
/* 17 */   public int getActualMaximum(int field) { throw new RuntimeException("Stub!"); } 
/* 18 */   public int getActualMinimum(int field) { throw new RuntimeException("Stub!"); } 
/* 19 */   public int getGreatestMinimum(int field) { throw new RuntimeException("Stub!"); } 
/* 20 */   public final Date getGregorianChange() { throw new RuntimeException("Stub!"); } 
/* 21 */   public int getLeastMaximum(int field) { throw new RuntimeException("Stub!"); } 
/* 22 */   public int getMaximum(int field) { throw new RuntimeException("Stub!"); } 
/* 23 */   public int getMinimum(int field) { throw new RuntimeException("Stub!"); } 
/* 24 */   public int hashCode() { throw new RuntimeException("Stub!"); } 
/* 25 */   public boolean isLeapYear(int year) { throw new RuntimeException("Stub!"); } 
/* 26 */   public void roll(int field, int value) { throw new RuntimeException("Stub!"); } 
/* 27 */   public void roll(int field, boolean increment) { throw new RuntimeException("Stub!"); } 
/* 28 */   public void setGregorianChange(Date date) { throw new RuntimeException("Stub!"); } 
/* 29 */   public void setFirstDayOfWeek(int value) { throw new RuntimeException("Stub!"); } 
/* 30 */   public void setMinimalDaysInFirstWeek(int value) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.GregorianCalendar
 * JD-Core Version:    0.6.0
 */