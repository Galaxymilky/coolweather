/*    */ package java.util;
/*    */ 
/*    */ public class Timer
/*    */ {
/*    */   public Timer(String name, boolean isDaemon)
/*    */   {
/*  4 */     throw new RuntimeException("Stub!"); } 
/*  5 */   public Timer(String name) { throw new RuntimeException("Stub!"); } 
/*  6 */   public Timer(boolean isDaemon) { throw new RuntimeException("Stub!"); } 
/*  7 */   public Timer() { throw new RuntimeException("Stub!"); } 
/*  8 */   public void cancel() { throw new RuntimeException("Stub!"); } 
/*  9 */   public int purge() { throw new RuntimeException("Stub!"); } 
/* 10 */   public void schedule(TimerTask task, Date when) { throw new RuntimeException("Stub!"); } 
/* 11 */   public void schedule(TimerTask task, long delay) { throw new RuntimeException("Stub!"); } 
/* 12 */   public void schedule(TimerTask task, long delay, long period) { throw new RuntimeException("Stub!"); } 
/* 13 */   public void schedule(TimerTask task, Date when, long period) { throw new RuntimeException("Stub!"); } 
/* 14 */   public void scheduleAtFixedRate(TimerTask task, long delay, long period) { throw new RuntimeException("Stub!"); } 
/* 15 */   public void scheduleAtFixedRate(TimerTask task, Date when, long period) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.Timer
 * JD-Core Version:    0.6.0
 */