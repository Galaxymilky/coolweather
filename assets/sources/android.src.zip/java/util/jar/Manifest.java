/*    */ package java.util.jar;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class Manifest
/*    */   implements Cloneable
/*    */ {
/*    */   public Manifest()
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public Manifest(InputStream is) throws IOException { throw new RuntimeException("Stub!"); } 
/*    */   public Manifest(Manifest man) {
/*  8 */     throw new RuntimeException("Stub!"); } 
/*  9 */   public void clear() { throw new RuntimeException("Stub!"); } 
/* 10 */   public Attributes getAttributes(String name) { throw new RuntimeException("Stub!"); } 
/* 11 */   public Map<String, Attributes> getEntries() { throw new RuntimeException("Stub!"); } 
/* 12 */   public Attributes getMainAttributes() { throw new RuntimeException("Stub!"); } 
/* 13 */   public Object clone() { throw new RuntimeException("Stub!"); } 
/* 14 */   public void write(OutputStream os) throws IOException { throw new RuntimeException("Stub!"); } 
/* 15 */   public void read(InputStream is) throws IOException { throw new RuntimeException("Stub!"); } 
/* 16 */   public int hashCode() { throw new RuntimeException("Stub!"); } 
/* 17 */   public boolean equals(Object o) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.jar.Manifest
 * JD-Core Version:    0.6.0
 */