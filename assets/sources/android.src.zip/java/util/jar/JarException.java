/*   */ package java.util.jar;
/*   */ 
/*   */ import java.util.zip.ZipException;
/*   */ 
/*   */ public class JarException extends ZipException
/*   */ {
/*   */   public JarException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public JarException(String detailMessage) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.jar.JarException
 * JD-Core Version:    0.6.0
 */