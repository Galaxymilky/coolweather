/*    */ package java.util.logging;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class FileHandler extends StreamHandler
/*    */ {
/*    */   public FileHandler()
/*    */     throws IOException
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public FileHandler(String pattern) throws IOException { throw new RuntimeException("Stub!"); } 
/*  7 */   public FileHandler(String pattern, boolean append) throws IOException { throw new RuntimeException("Stub!"); } 
/*  8 */   public FileHandler(String pattern, int limit, int count) throws IOException { throw new RuntimeException("Stub!"); } 
/*  9 */   public FileHandler(String pattern, int limit, int count, boolean append) throws IOException { throw new RuntimeException("Stub!"); } 
/* 10 */   public void close() { throw new RuntimeException("Stub!"); } 
/* 11 */   public synchronized void publish(LogRecord record) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.logging.FileHandler
 * JD-Core Version:    0.6.0
 */