/*   */ package java.util.logging;
/*   */ 
/*   */ public class ConsoleHandler extends StreamHandler
/*   */ {
/*   */   public ConsoleHandler()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public void close() { throw new RuntimeException("Stub!"); } 
/* 7 */   public void publish(LogRecord record) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.logging.ConsoleHandler
 * JD-Core Version:    0.6.0
 */