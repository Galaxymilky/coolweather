package java.util.logging;

public abstract interface Filter
{
  public abstract boolean isLoggable(LogRecord paramLogRecord);
}

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.logging.Filter
 * JD-Core Version:    0.6.0
 */