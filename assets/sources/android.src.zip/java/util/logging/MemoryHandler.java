/*    */ package java.util.logging;
/*    */ 
/*    */ public class MemoryHandler extends Handler
/*    */ {
/*    */   public MemoryHandler()
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public MemoryHandler(Handler target, int size, Level pushLevel) { throw new RuntimeException("Stub!"); } 
/*  7 */   public void close() { throw new RuntimeException("Stub!"); } 
/*  8 */   public void flush() { throw new RuntimeException("Stub!"); } 
/*  9 */   public synchronized void publish(LogRecord record) { throw new RuntimeException("Stub!"); } 
/* 10 */   public Level getPushLevel() { throw new RuntimeException("Stub!"); } 
/* 11 */   public boolean isLoggable(LogRecord record) { throw new RuntimeException("Stub!"); } 
/* 12 */   public void push() { throw new RuntimeException("Stub!"); } 
/* 13 */   public void setPushLevel(Level newLevel) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.logging.MemoryHandler
 * JD-Core Version:    0.6.0
 */