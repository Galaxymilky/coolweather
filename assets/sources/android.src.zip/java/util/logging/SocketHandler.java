/*   */ package java.util.logging;
/*   */ 
/*   */ import java.io.IOException;
/*   */ 
/*   */ public class SocketHandler extends StreamHandler
/*   */ {
/*   */   public SocketHandler()
/*   */     throws IOException
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public SocketHandler(String host, int port) throws IOException { throw new RuntimeException("Stub!"); } 
/* 7 */   public void close() { throw new RuntimeException("Stub!"); } 
/* 8 */   public void publish(LogRecord record) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.logging.SocketHandler
 * JD-Core Version:    0.6.0
 */