/*    */ package java.util.logging;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ public class LogRecord
/*    */   implements Serializable
/*    */ {
/*    */   public LogRecord(Level level, String msg)
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public Level getLevel() { throw new RuntimeException("Stub!"); } 
/*  7 */   public void setLevel(Level level) { throw new RuntimeException("Stub!"); } 
/*  8 */   public String getLoggerName() { throw new RuntimeException("Stub!"); } 
/*  9 */   public void setLoggerName(String loggerName) { throw new RuntimeException("Stub!"); } 
/* 10 */   public String getMessage() { throw new RuntimeException("Stub!"); } 
/* 11 */   public void setMessage(String message) { throw new RuntimeException("Stub!"); } 
/* 12 */   public long getMillis() { throw new RuntimeException("Stub!"); } 
/* 13 */   public void setMillis(long millis) { throw new RuntimeException("Stub!"); } 
/* 14 */   public Object[] getParameters() { throw new RuntimeException("Stub!"); } 
/* 15 */   public void setParameters(Object[] parameters) { throw new RuntimeException("Stub!"); } 
/* 16 */   public ResourceBundle getResourceBundle() { throw new RuntimeException("Stub!"); } 
/* 17 */   public void setResourceBundle(ResourceBundle resourceBundle) { throw new RuntimeException("Stub!"); } 
/* 18 */   public String getResourceBundleName() { throw new RuntimeException("Stub!"); } 
/* 19 */   public void setResourceBundleName(String resourceBundleName) { throw new RuntimeException("Stub!"); } 
/* 20 */   public long getSequenceNumber() { throw new RuntimeException("Stub!"); } 
/* 21 */   public void setSequenceNumber(long sequenceNumber) { throw new RuntimeException("Stub!"); } 
/* 22 */   public String getSourceClassName() { throw new RuntimeException("Stub!"); } 
/* 23 */   public void setSourceClassName(String sourceClassName) { throw new RuntimeException("Stub!"); } 
/* 24 */   public String getSourceMethodName() { throw new RuntimeException("Stub!"); } 
/* 25 */   public void setSourceMethodName(String sourceMethodName) { throw new RuntimeException("Stub!"); } 
/* 26 */   public int getThreadID() { throw new RuntimeException("Stub!"); } 
/* 27 */   public void setThreadID(int threadID) { throw new RuntimeException("Stub!"); } 
/* 28 */   public Throwable getThrown() { throw new RuntimeException("Stub!"); } 
/* 29 */   public void setThrown(Throwable thrown) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.logging.LogRecord
 * JD-Core Version:    0.6.0
 */