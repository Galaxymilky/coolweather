/*   */ package java.util.logging;
/*   */ 
/*   */ public class SimpleFormatter extends Formatter
/*   */ {
/*   */   public SimpleFormatter()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public String format(LogRecord r) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.logging.SimpleFormatter
 * JD-Core Version:    0.6.0
 */