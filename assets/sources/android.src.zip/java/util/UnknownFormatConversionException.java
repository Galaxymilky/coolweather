/*   */ package java.util;
/*   */ 
/*   */ public class UnknownFormatConversionException extends IllegalFormatException
/*   */ {
/*   */   public UnknownFormatConversionException(String s)
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public String getConversion() { throw new RuntimeException("Stub!"); } 
/* 7 */   public String getMessage() { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.UnknownFormatConversionException
 * JD-Core Version:    0.6.0
 */