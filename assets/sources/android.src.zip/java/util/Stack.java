/*    */ package java.util;
/*    */ 
/*    */ public class Stack<E> extends Vector<E>
/*    */ {
/*    */   public Stack()
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public boolean empty() { throw new RuntimeException("Stub!"); } 
/*    */   public synchronized E peek() {
/*  8 */     throw new RuntimeException("Stub!");
/*    */   }
/* 10 */   public synchronized E pop() { throw new RuntimeException("Stub!"); } 
/* 11 */   public E push(E object) { throw new RuntimeException("Stub!"); } 
/* 12 */   public synchronized int search(Object o) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.Stack
 * JD-Core Version:    0.6.0
 */