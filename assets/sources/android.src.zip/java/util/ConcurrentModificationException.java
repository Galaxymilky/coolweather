/*   */ package java.util;
/*   */ 
/*   */ public class ConcurrentModificationException extends RuntimeException
/*   */ {
/*   */   public ConcurrentModificationException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public ConcurrentModificationException(String detailMessage) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.ConcurrentModificationException
 * JD-Core Version:    0.6.0
 */