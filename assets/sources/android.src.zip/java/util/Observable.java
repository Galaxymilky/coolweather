/*    */ package java.util;
/*    */ 
/*    */ public class Observable
/*    */ {
/*    */   public Observable()
/*    */   {
/*  4 */     throw new RuntimeException("Stub!"); } 
/*  5 */   public void addObserver(Observer observer) { throw new RuntimeException("Stub!"); } 
/*  6 */   protected void clearChanged() { throw new RuntimeException("Stub!"); } 
/*  7 */   public int countObservers() { throw new RuntimeException("Stub!"); } 
/*  8 */   public synchronized void deleteObserver(Observer observer) { throw new RuntimeException("Stub!"); } 
/*  9 */   public synchronized void deleteObservers() { throw new RuntimeException("Stub!"); } 
/* 10 */   public boolean hasChanged() { throw new RuntimeException("Stub!"); } 
/* 11 */   public void notifyObservers() { throw new RuntimeException("Stub!"); } 
/*    */   public void notifyObservers(Object data) {
/* 13 */     throw new RuntimeException("Stub!"); } 
/* 14 */   protected void setChanged() { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.Observable
 * JD-Core Version:    0.6.0
 */