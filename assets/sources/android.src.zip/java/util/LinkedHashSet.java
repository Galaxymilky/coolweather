/*   */ package java.util;
/*   */ 
/*   */ import java.io.Serializable;
/*   */ 
/*   */ public class LinkedHashSet<E> extends HashSet<E>
/*   */   implements Set<E>, Cloneable, Serializable
/*   */ {
/*   */   public LinkedHashSet()
/*   */   {
/* 6 */     throw new RuntimeException("Stub!"); } 
/* 7 */   public LinkedHashSet(int capacity) { throw new RuntimeException("Stub!"); } 
/* 8 */   public LinkedHashSet(int capacity, float loadFactor) { throw new RuntimeException("Stub!"); } 
/* 9 */   public LinkedHashSet(Collection<? extends E> collection) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.LinkedHashSet
 * JD-Core Version:    0.6.0
 */