/*   */ package java.util;
/*   */ 
/*   */ import java.security.BasicPermission;
/*   */ import java.security.Permission;
/*   */ 
/*   */ public final class PropertyPermission extends BasicPermission
/*   */ {
/*   */   public PropertyPermission(String name, String actions)
/*   */   {
/* 5 */     super((String)null, (String)null); throw new RuntimeException("Stub!"); } 
/* 6 */   public String getActions() { throw new RuntimeException("Stub!"); } 
/* 7 */   public boolean implies(Permission permission) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.PropertyPermission
 * JD-Core Version:    0.6.0
 */