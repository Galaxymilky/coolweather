/*    */ package java.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public final class UUID
/*    */   implements Serializable, Comparable<UUID>
/*    */ {
/*    */   public UUID(long mostSigBits, long leastSigBits)
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public static UUID randomUUID() { throw new RuntimeException("Stub!"); } 
/*  7 */   public static UUID nameUUIDFromBytes(byte[] name) { throw new RuntimeException("Stub!"); } 
/*  8 */   public static UUID fromString(String uuid) { throw new RuntimeException("Stub!"); } 
/*  9 */   public long getLeastSignificantBits() { throw new RuntimeException("Stub!"); } 
/* 10 */   public long getMostSignificantBits() { throw new RuntimeException("Stub!"); } 
/* 11 */   public int version() { throw new RuntimeException("Stub!"); } 
/* 12 */   public int variant() { throw new RuntimeException("Stub!"); } 
/* 13 */   public long timestamp() { throw new RuntimeException("Stub!"); } 
/* 14 */   public int clockSequence() { throw new RuntimeException("Stub!"); } 
/* 15 */   public long node() { throw new RuntimeException("Stub!"); } 
/* 16 */   public int compareTo(UUID uuid) { throw new RuntimeException("Stub!"); } 
/* 17 */   public boolean equals(Object object) { throw new RuntimeException("Stub!"); } 
/* 18 */   public int hashCode() { throw new RuntimeException("Stub!"); } 
/* 19 */   public String toString() { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.UUID
 * JD-Core Version:    0.6.0
 */