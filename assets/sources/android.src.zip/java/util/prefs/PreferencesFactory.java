package java.util.prefs;

public abstract interface PreferencesFactory
{
  public abstract Preferences userRoot();

  public abstract Preferences systemRoot();
}

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.prefs.PreferencesFactory
 * JD-Core Version:    0.6.0
 */