/*   */ package java.util.prefs;
/*   */ 
/*   */ public class InvalidPreferencesFormatException extends Exception
/*   */ {
/*   */   public InvalidPreferencesFormatException(String s)
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public InvalidPreferencesFormatException(String s, Throwable t) { throw new RuntimeException("Stub!"); } 
/* 7 */   public InvalidPreferencesFormatException(Throwable t) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.prefs.InvalidPreferencesFormatException
 * JD-Core Version:    0.6.0
 */