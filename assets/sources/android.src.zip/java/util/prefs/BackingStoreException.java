/*   */ package java.util.prefs;
/*   */ 
/*   */ public class BackingStoreException extends Exception
/*   */ {
/*   */   public BackingStoreException(String s)
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public BackingStoreException(Throwable t) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.prefs.BackingStoreException
 * JD-Core Version:    0.6.0
 */