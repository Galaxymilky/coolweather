/*    */ package java.util;
/*    */ 
/*    */ public class LinkedHashMap<K, V> extends HashMap<K, V>
/*    */ {
/*    */   public LinkedHashMap()
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public LinkedHashMap(int initialCapacity) { throw new RuntimeException("Stub!"); } 
/*  7 */   public LinkedHashMap(int initialCapacity, float loadFactor) { throw new RuntimeException("Stub!"); } 
/*  8 */   public LinkedHashMap(int initialCapacity, float loadFactor, boolean accessOrder) { throw new RuntimeException("Stub!"); } 
/*  9 */   public LinkedHashMap(Map<? extends K, ? extends V> map) { throw new RuntimeException("Stub!"); } 
/* 10 */   public V get(Object key) { throw new RuntimeException("Stub!"); } 
/* 11 */   public boolean containsValue(Object value) { throw new RuntimeException("Stub!"); } 
/* 12 */   public void clear() { throw new RuntimeException("Stub!"); } 
/* 13 */   protected boolean removeEldestEntry(Map.Entry<K, V> eldest) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.LinkedHashMap
 * JD-Core Version:    0.6.0
 */