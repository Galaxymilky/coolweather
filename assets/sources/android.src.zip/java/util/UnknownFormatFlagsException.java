/*   */ package java.util;
/*   */ 
/*   */ public class UnknownFormatFlagsException extends IllegalFormatException
/*   */ {
/*   */   public UnknownFormatFlagsException(String f)
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public String getFlags() { throw new RuntimeException("Stub!"); } 
/* 7 */   public String getMessage() { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.UnknownFormatFlagsException
 * JD-Core Version:    0.6.0
 */