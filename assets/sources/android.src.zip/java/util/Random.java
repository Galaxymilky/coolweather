/*    */ package java.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class Random
/*    */   implements Serializable
/*    */ {
/*    */   public Random()
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public Random(long seed) { throw new RuntimeException("Stub!"); } 
/*  7 */   protected synchronized int next(int bits) { throw new RuntimeException("Stub!"); } 
/*  8 */   public boolean nextBoolean() { throw new RuntimeException("Stub!"); } 
/*  9 */   public void nextBytes(byte[] buf) { throw new RuntimeException("Stub!"); } 
/* 10 */   public double nextDouble() { throw new RuntimeException("Stub!"); } 
/* 11 */   public float nextFloat() { throw new RuntimeException("Stub!"); } 
/* 12 */   public synchronized double nextGaussian() { throw new RuntimeException("Stub!"); } 
/* 13 */   public int nextInt() { throw new RuntimeException("Stub!"); } 
/* 14 */   public int nextInt(int n) { throw new RuntimeException("Stub!"); } 
/* 15 */   public long nextLong() { throw new RuntimeException("Stub!"); } 
/* 16 */   public synchronized void setSeed(long seed) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.Random
 * JD-Core Version:    0.6.0
 */