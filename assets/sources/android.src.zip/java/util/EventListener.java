package java.util;

public abstract interface EventListener
{
}

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.EventListener
 * JD-Core Version:    0.6.0
 */