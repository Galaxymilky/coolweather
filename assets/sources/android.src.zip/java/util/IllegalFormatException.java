/*   */ package java.util;
/*   */ 
/*   */ import java.io.Serializable;
/*   */ 
/*   */ public class IllegalFormatException extends IllegalArgumentException
/*   */   implements Serializable
/*   */ {
/*   */   IllegalFormatException()
/*   */   {
/* 6 */     throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.IllegalFormatException
 * JD-Core Version:    0.6.0
 */