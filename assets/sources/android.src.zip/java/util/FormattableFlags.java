/*   */ package java.util;
/*   */ 
/*   */ public class FormattableFlags
/*   */ {
/*   */   public static final int LEFT_JUSTIFY = 1;
/*   */   public static final int UPPERCASE = 2;
/*   */   public static final int ALTERNATE = 4;
/*   */ 
/*   */   FormattableFlags()
/*   */   {
/* 4 */     throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.FormattableFlags
 * JD-Core Version:    0.6.0
 */