/*   */ package java.util;
/*   */ 
/*   */ public class NoSuchElementException extends RuntimeException
/*   */ {
/*   */   public NoSuchElementException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public NoSuchElementException(String detailMessage) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.NoSuchElementException
 * JD-Core Version:    0.6.0
 */