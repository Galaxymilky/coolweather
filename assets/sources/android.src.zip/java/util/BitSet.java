/*    */ package java.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class BitSet
/*    */   implements Serializable, Cloneable
/*    */ {
/*    */   public BitSet()
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public BitSet(int bitCount) { throw new RuntimeException("Stub!"); } 
/*  7 */   public Object clone() { throw new RuntimeException("Stub!"); } 
/*  8 */   public boolean equals(Object o) { throw new RuntimeException("Stub!"); } 
/*  9 */   public int hashCode() { throw new RuntimeException("Stub!"); } 
/* 10 */   public boolean get(int index) { throw new RuntimeException("Stub!"); } 
/* 11 */   public void set(int index) { throw new RuntimeException("Stub!"); } 
/* 12 */   public void clear(int index) { throw new RuntimeException("Stub!"); } 
/* 13 */   public void flip(int index) { throw new RuntimeException("Stub!"); } 
/* 14 */   public BitSet get(int fromIndex, int toIndex) { throw new RuntimeException("Stub!"); } 
/* 15 */   public void set(int index, boolean state) { throw new RuntimeException("Stub!"); } 
/* 16 */   public void set(int fromIndex, int toIndex, boolean state) { throw new RuntimeException("Stub!"); } 
/* 17 */   public void clear() { throw new RuntimeException("Stub!"); } 
/* 18 */   public void set(int fromIndex, int toIndex) { throw new RuntimeException("Stub!"); } 
/* 19 */   public void clear(int fromIndex, int toIndex) { throw new RuntimeException("Stub!"); } 
/* 20 */   public void flip(int fromIndex, int toIndex) { throw new RuntimeException("Stub!"); } 
/* 21 */   public boolean intersects(BitSet bs) { throw new RuntimeException("Stub!"); } 
/* 22 */   public void and(BitSet bs) { throw new RuntimeException("Stub!"); } 
/* 23 */   public void andNot(BitSet bs) { throw new RuntimeException("Stub!"); } 
/* 24 */   public void or(BitSet bs) { throw new RuntimeException("Stub!"); } 
/* 25 */   public void xor(BitSet bs) { throw new RuntimeException("Stub!"); } 
/* 26 */   public int size() { throw new RuntimeException("Stub!"); } 
/* 27 */   public int length() { throw new RuntimeException("Stub!"); } 
/* 28 */   public String toString() { throw new RuntimeException("Stub!"); } 
/* 29 */   public int nextSetBit(int index) { throw new RuntimeException("Stub!"); } 
/* 30 */   public int nextClearBit(int index) { throw new RuntimeException("Stub!"); } 
/* 31 */   public boolean isEmpty() { throw new RuntimeException("Stub!"); } 
/* 32 */   public int cardinality() { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.BitSet
 * JD-Core Version:    0.6.0
 */