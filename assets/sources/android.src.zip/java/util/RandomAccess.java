package java.util;

public abstract interface RandomAccess
{
}

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.RandomAccess
 * JD-Core Version:    0.6.0
 */