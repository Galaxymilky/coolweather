/*   */ package java.util;
/*   */ 
/*   */ import java.io.Serializable;
/*   */ 
/*   */ public class IllegalFormatConversionException extends IllegalFormatException
/*   */   implements Serializable
/*   */ {
/*   */   public IllegalFormatConversionException(char c, Class<?> arg)
/*   */   {
/* 6 */     throw new RuntimeException("Stub!"); } 
/* 7 */   public Class<?> getArgumentClass() { throw new RuntimeException("Stub!"); } 
/* 8 */   public char getConversion() { throw new RuntimeException("Stub!"); } 
/* 9 */   public String getMessage() { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.IllegalFormatConversionException
 * JD-Core Version:    0.6.0
 */