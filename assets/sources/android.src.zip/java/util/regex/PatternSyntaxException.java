/*   */ package java.util.regex;
/*   */ 
/*   */ public class PatternSyntaxException extends IllegalArgumentException
/*   */ {
/*   */   public PatternSyntaxException(String description, String pattern, int index)
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public String getPattern() { throw new RuntimeException("Stub!"); } 
/* 7 */   public String getMessage() { throw new RuntimeException("Stub!"); } 
/* 8 */   public String getDescription() { throw new RuntimeException("Stub!"); } 
/* 9 */   public int getIndex() { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.regex.PatternSyntaxException
 * JD-Core Version:    0.6.0
 */