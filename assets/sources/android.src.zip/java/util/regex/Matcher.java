/*    */ package java.util.regex;
/*    */ 
/*    */ public final class Matcher
/*    */   implements MatchResult
/*    */ {
/*    */   Matcher()
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public Matcher appendReplacement(StringBuffer buffer, String replacement) { throw new RuntimeException("Stub!"); } 
/*  7 */   public Matcher reset() { throw new RuntimeException("Stub!"); } 
/*  8 */   public Matcher reset(CharSequence input) { throw new RuntimeException("Stub!"); } 
/*  9 */   public Matcher usePattern(Pattern pattern) { throw new RuntimeException("Stub!"); } 
/* 10 */   public Matcher region(int start, int end) { throw new RuntimeException("Stub!"); } 
/* 11 */   public StringBuffer appendTail(StringBuffer buffer) { throw new RuntimeException("Stub!"); } 
/* 12 */   public String replaceFirst(String replacement) { throw new RuntimeException("Stub!"); } 
/* 13 */   public String replaceAll(String replacement) { throw new RuntimeException("Stub!"); } 
/* 14 */   public Pattern pattern() { throw new RuntimeException("Stub!"); } 
/* 15 */   public String group(int group) { throw new RuntimeException("Stub!"); } 
/* 16 */   public String group() { throw new RuntimeException("Stub!"); } 
/* 17 */   public boolean find(int start) { throw new RuntimeException("Stub!"); } 
/* 18 */   public boolean find() { throw new RuntimeException("Stub!"); } 
/* 19 */   public boolean lookingAt() { throw new RuntimeException("Stub!"); } 
/* 20 */   public boolean matches() { throw new RuntimeException("Stub!"); } 
/* 21 */   public int start(int group) throws IllegalStateException { throw new RuntimeException("Stub!"); } 
/* 22 */   public int end(int group) { throw new RuntimeException("Stub!"); } 
/* 23 */   public static String quoteReplacement(String s) { throw new RuntimeException("Stub!"); } 
/* 24 */   public int start() { throw new RuntimeException("Stub!"); } 
/* 25 */   public int groupCount() { throw new RuntimeException("Stub!"); } 
/* 26 */   public int end() { throw new RuntimeException("Stub!"); } 
/* 27 */   public MatchResult toMatchResult() { throw new RuntimeException("Stub!"); } 
/* 28 */   public Matcher useAnchoringBounds(boolean value) { throw new RuntimeException("Stub!"); } 
/* 29 */   public boolean hasAnchoringBounds() { throw new RuntimeException("Stub!"); } 
/* 30 */   public Matcher useTransparentBounds(boolean value) { throw new RuntimeException("Stub!"); } 
/* 31 */   public boolean hasTransparentBounds() { throw new RuntimeException("Stub!"); } 
/* 32 */   public int regionStart() { throw new RuntimeException("Stub!"); } 
/* 33 */   public int regionEnd() { throw new RuntimeException("Stub!"); } 
/* 34 */   public boolean requireEnd() { throw new RuntimeException("Stub!"); } 
/* 35 */   public boolean hitEnd() { throw new RuntimeException("Stub!"); } 
/* 36 */   protected void finalize() throws Throwable { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.regex.Matcher
 * JD-Core Version:    0.6.0
 */