/*   */ package java.util;
/*   */ 
/*   */ public class MissingFormatArgumentException extends IllegalFormatException
/*   */ {
/*   */   public MissingFormatArgumentException(String s)
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public String getFormatSpecifier() { throw new RuntimeException("Stub!"); } 
/* 7 */   public String getMessage() { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.MissingFormatArgumentException
 * JD-Core Version:    0.6.0
 */