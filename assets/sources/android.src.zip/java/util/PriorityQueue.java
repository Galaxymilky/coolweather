/*    */ package java.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class PriorityQueue<E> extends AbstractQueue<E>
/*    */   implements Serializable
/*    */ {
/*    */   public PriorityQueue()
/*    */   {
/*  6 */     throw new RuntimeException("Stub!"); } 
/*  7 */   public PriorityQueue(int initialCapacity) { throw new RuntimeException("Stub!"); } 
/*  8 */   public PriorityQueue(int initialCapacity, Comparator<? super E> comparator) { throw new RuntimeException("Stub!"); } 
/*  9 */   public PriorityQueue(Collection<? extends E> c) { throw new RuntimeException("Stub!"); } 
/* 10 */   public PriorityQueue(PriorityQueue<? extends E> c) { throw new RuntimeException("Stub!"); } 
/* 11 */   public PriorityQueue(SortedSet<? extends E> c) { throw new RuntimeException("Stub!"); } 
/* 12 */   public Iterator<E> iterator() { throw new RuntimeException("Stub!"); } 
/* 13 */   public int size() { throw new RuntimeException("Stub!"); } 
/* 14 */   public void clear() { throw new RuntimeException("Stub!"); } 
/* 15 */   public boolean offer(E o) { throw new RuntimeException("Stub!"); } 
/* 16 */   public E poll() { throw new RuntimeException("Stub!"); } 
/* 17 */   public E peek() { throw new RuntimeException("Stub!"); } 
/* 18 */   public Comparator<? super E> comparator() { throw new RuntimeException("Stub!"); } 
/*    */   public boolean remove(Object o) {
/* 20 */     throw new RuntimeException("Stub!"); } 
/* 21 */   public boolean add(E o) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.PriorityQueue
 * JD-Core Version:    0.6.0
 */