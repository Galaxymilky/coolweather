/*   */ package java.util;
/*   */ 
/*   */ import java.io.Serializable;
/*   */ 
/*   */ public class IllegalFormatFlagsException extends IllegalFormatException
/*   */   implements Serializable
/*   */ {
/*   */   public IllegalFormatFlagsException(String flags)
/*   */   {
/* 6 */     throw new RuntimeException("Stub!"); } 
/* 7 */   public String getFlags() { throw new RuntimeException("Stub!"); } 
/* 8 */   public String getMessage() { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.IllegalFormatFlagsException
 * JD-Core Version:    0.6.0
 */