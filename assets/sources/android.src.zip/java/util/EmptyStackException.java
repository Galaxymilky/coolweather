/*   */ package java.util;
/*   */ 
/*   */ public class EmptyStackException extends RuntimeException
/*   */ {
/*   */   public EmptyStackException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.EmptyStackException
 * JD-Core Version:    0.6.0
 */