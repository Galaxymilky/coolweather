package java.util;

public abstract interface Formattable
{
  public abstract void formatTo(Formatter paramFormatter, int paramInt1, int paramInt2, int paramInt3)
    throws IllegalFormatException;
}

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.Formattable
 * JD-Core Version:    0.6.0
 */