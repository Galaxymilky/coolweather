/*   */ package java.util;
/*   */ 
/*   */ import java.io.Serializable;
/*   */ 
/*   */ public class EventObject
/*   */   implements Serializable
/*   */ {
/*   */   protected transient Object source;
/*   */ 
/*   */   public EventObject(Object source)
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public Object getSource() { throw new RuntimeException("Stub!"); } 
/* 7 */   public String toString() { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.EventObject
 * JD-Core Version:    0.6.0
 */