package java.util;

public abstract interface Enumeration<E>
{
  public abstract boolean hasMoreElements();

  public abstract E nextElement();
}

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.Enumeration
 * JD-Core Version:    0.6.0
 */