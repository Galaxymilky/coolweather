/*   */ package java.util;
/*   */ 
/*   */ public abstract class AbstractSet<E> extends AbstractCollection<E>
/*   */   implements Set<E>
/*   */ {
/*   */   protected AbstractSet()
/*   */   {
/* 6 */     throw new RuntimeException("Stub!"); } 
/* 7 */   public boolean equals(Object object) { throw new RuntimeException("Stub!"); } 
/* 8 */   public int hashCode() { throw new RuntimeException("Stub!"); } 
/* 9 */   public boolean removeAll(Collection<?> collection) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.AbstractSet
 * JD-Core Version:    0.6.0
 */