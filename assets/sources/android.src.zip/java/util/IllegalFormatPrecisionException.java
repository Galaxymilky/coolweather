/*   */ package java.util;
/*   */ 
/*   */ public class IllegalFormatPrecisionException extends IllegalFormatException
/*   */ {
/*   */   public IllegalFormatPrecisionException(int p)
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public int getPrecision() { throw new RuntimeException("Stub!"); } 
/* 7 */   public String getMessage() { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.IllegalFormatPrecisionException
 * JD-Core Version:    0.6.0
 */