/*   */ package java.util;
/*   */ 
/*   */ import java.io.Serializable;
/*   */ 
/*   */ public class FormatterClosedException extends IllegalStateException
/*   */   implements Serializable
/*   */ {
/*   */   public FormatterClosedException()
/*   */   {
/* 6 */     throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.FormatterClosedException
 * JD-Core Version:    0.6.0
 */