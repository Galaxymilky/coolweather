/*    */ package java.util;
/*    */ 
/*    */ public abstract class AbstractQueue<E> extends AbstractCollection<E>
/*    */   implements Queue<E>
/*    */ {
/*    */   protected AbstractQueue()
/*    */   {
/*  6 */     throw new RuntimeException("Stub!"); } 
/*  7 */   public boolean add(E e) { throw new RuntimeException("Stub!"); } 
/*  8 */   public E remove() { throw new RuntimeException("Stub!"); } 
/*  9 */   public E element() { throw new RuntimeException("Stub!"); } 
/* 10 */   public void clear() { throw new RuntimeException("Stub!"); } 
/* 11 */   public boolean addAll(Collection<? extends E> c) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.AbstractQueue
 * JD-Core Version:    0.6.0
 */