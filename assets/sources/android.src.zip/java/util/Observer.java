package java.util;

public abstract interface Observer
{
  public abstract void update(Observable paramObservable, Object paramObject);
}

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.Observer
 * JD-Core Version:    0.6.0
 */