package java.util;

public abstract interface Comparator<T>
{
  public abstract int compare(T paramT1, T paramT2);

  public abstract boolean equals(Object paramObject);
}

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.Comparator
 * JD-Core Version:    0.6.0
 */