/*   */ package java.util;
/*   */ 
/*   */ public abstract class EventListenerProxy
/*   */   implements EventListener
/*   */ {
/*   */   public EventListenerProxy(EventListener listener)
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public EventListener getListener() { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.EventListenerProxy
 * JD-Core Version:    0.6.0
 */