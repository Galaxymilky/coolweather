/*    */ package java.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class HashSet<E> extends AbstractSet<E>
/*    */   implements Set<E>, Cloneable, Serializable
/*    */ {
/*    */   public HashSet()
/*    */   {
/*  6 */     throw new RuntimeException("Stub!"); } 
/*  7 */   public HashSet(int capacity) { throw new RuntimeException("Stub!"); } 
/*  8 */   public HashSet(int capacity, float loadFactor) { throw new RuntimeException("Stub!"); } 
/*  9 */   public HashSet(Collection<? extends E> collection) { throw new RuntimeException("Stub!"); } 
/* 10 */   public boolean add(E object) { throw new RuntimeException("Stub!"); } 
/* 11 */   public void clear() { throw new RuntimeException("Stub!"); } 
/*    */   public Object clone() {
/* 13 */     throw new RuntimeException("Stub!"); } 
/* 14 */   public boolean contains(Object object) { throw new RuntimeException("Stub!"); } 
/* 15 */   public boolean isEmpty() { throw new RuntimeException("Stub!"); } 
/* 16 */   public Iterator<E> iterator() { throw new RuntimeException("Stub!"); } 
/* 17 */   public boolean remove(Object object) { throw new RuntimeException("Stub!"); } 
/* 18 */   public int size() { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.HashSet
 * JD-Core Version:    0.6.0
 */