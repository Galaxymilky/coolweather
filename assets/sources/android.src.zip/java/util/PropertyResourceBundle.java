/*   */ package java.util;
/*   */ 
/*   */ import java.io.IOException;
/*   */ import java.io.InputStream;
/*   */ import java.io.Reader;
/*   */ 
/*   */ public class PropertyResourceBundle extends ResourceBundle
/*   */ {
/*   */   public PropertyResourceBundle(InputStream stream)
/*   */     throws IOException
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public PropertyResourceBundle(Reader reader) throws IOException { throw new RuntimeException("Stub!"); } 
/* 7 */   protected Set<String> handleKeySet() { throw new RuntimeException("Stub!"); } 
/* 8 */   public Enumeration<String> getKeys() { throw new RuntimeException("Stub!"); } 
/* 9 */   public Object handleGetObject(String key) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.PropertyResourceBundle
 * JD-Core Version:    0.6.0
 */