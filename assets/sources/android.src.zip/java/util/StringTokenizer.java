/*    */ package java.util;
/*    */ 
/*    */ public class StringTokenizer
/*    */   implements Enumeration<Object>
/*    */ {
/*    */   public StringTokenizer(String string)
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public StringTokenizer(String string, String delimiters) { throw new RuntimeException("Stub!"); } 
/*  7 */   public StringTokenizer(String string, String delimiters, boolean returnDelimiters) { throw new RuntimeException("Stub!"); } 
/*  8 */   public int countTokens() { throw new RuntimeException("Stub!"); } 
/*  9 */   public boolean hasMoreElements() { throw new RuntimeException("Stub!"); } 
/* 10 */   public boolean hasMoreTokens() { throw new RuntimeException("Stub!"); } 
/* 11 */   public Object nextElement() { throw new RuntimeException("Stub!"); } 
/* 12 */   public String nextToken() { throw new RuntimeException("Stub!"); } 
/* 13 */   public String nextToken(String delims) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.StringTokenizer
 * JD-Core Version:    0.6.0
 */