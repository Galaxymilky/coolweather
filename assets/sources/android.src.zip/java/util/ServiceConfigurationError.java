/*   */ package java.util;
/*   */ 
/*   */ public class ServiceConfigurationError extends Error
/*   */ {
/*   */   public ServiceConfigurationError(String message)
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public ServiceConfigurationError(String message, Throwable cause) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.ServiceConfigurationError
 * JD-Core Version:    0.6.0
 */