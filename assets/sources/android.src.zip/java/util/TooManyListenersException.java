/*   */ package java.util;
/*   */ 
/*   */ public class TooManyListenersException extends Exception
/*   */ {
/*   */   public TooManyListenersException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public TooManyListenersException(String detailMessage) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.TooManyListenersException
 * JD-Core Version:    0.6.0
 */