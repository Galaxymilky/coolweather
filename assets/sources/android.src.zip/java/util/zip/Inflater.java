/*    */ package java.util.zip;
/*    */ 
/*    */ public class Inflater
/*    */ {
/*    */   public Inflater()
/*    */   {
/*  4 */     throw new RuntimeException("Stub!"); } 
/*  5 */   public Inflater(boolean noHeader) { throw new RuntimeException("Stub!"); } 
/*  6 */   public synchronized void end() { throw new RuntimeException("Stub!"); } 
/*  7 */   protected void finalize() { throw new RuntimeException("Stub!"); } 
/*  8 */   public synchronized boolean finished() { throw new RuntimeException("Stub!"); } 
/*  9 */   public synchronized int getAdler() { throw new RuntimeException("Stub!"); } 
/* 10 */   public synchronized long getBytesRead() { throw new RuntimeException("Stub!"); } 
/* 11 */   public synchronized long getBytesWritten() { throw new RuntimeException("Stub!"); } 
/* 12 */   public synchronized int getRemaining() { throw new RuntimeException("Stub!"); } 
/* 13 */   public synchronized int getTotalIn() { throw new RuntimeException("Stub!"); } 
/* 14 */   public synchronized int getTotalOut() { throw new RuntimeException("Stub!"); } 
/* 15 */   public int inflate(byte[] buf) throws DataFormatException { throw new RuntimeException("Stub!"); } 
/* 16 */   public synchronized int inflate(byte[] buf, int offset, int byteCount) throws DataFormatException { throw new RuntimeException("Stub!"); } 
/* 17 */   public synchronized boolean needsDictionary() { throw new RuntimeException("Stub!"); } 
/* 18 */   public synchronized boolean needsInput() { throw new RuntimeException("Stub!"); } 
/* 19 */   public synchronized void reset() { throw new RuntimeException("Stub!"); } 
/* 20 */   public synchronized void setDictionary(byte[] dictionary) { throw new RuntimeException("Stub!"); } 
/* 21 */   public synchronized void setDictionary(byte[] dictionary, int offset, int byteCount) { throw new RuntimeException("Stub!"); } 
/* 22 */   public synchronized void setInput(byte[] buf) { throw new RuntimeException("Stub!"); } 
/* 23 */   public synchronized void setInput(byte[] buf, int offset, int byteCount) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.zip.Inflater
 * JD-Core Version:    0.6.0
 */