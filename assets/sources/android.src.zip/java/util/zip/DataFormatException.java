/*   */ package java.util.zip;
/*   */ 
/*   */ public class DataFormatException extends Exception
/*   */ {
/*   */   public DataFormatException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public DataFormatException(String detailMessage) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.zip.DataFormatException
 * JD-Core Version:    0.6.0
 */