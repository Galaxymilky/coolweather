/*   */ package java.util.zip;
/*   */ 
/*   */ public class ZipError extends InternalError
/*   */ {
/*   */   public ZipError(String s)
/*   */   {
/* 5 */     throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.zip.ZipError
 * JD-Core Version:    0.6.0
 */