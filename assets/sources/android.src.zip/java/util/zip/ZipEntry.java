/*    */ package java.util.zip;
/*    */ 
/*    */ public class ZipEntry
/*    */   implements Cloneable
/*    */ {
/*    */   public static final int DEFLATED = 8;
/*    */   public static final int STORED = 0;
/*    */ 
/*    */   public ZipEntry(String name)
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public ZipEntry(ZipEntry ze) { throw new RuntimeException("Stub!"); } 
/*  7 */   public String getComment() { throw new RuntimeException("Stub!"); } 
/*  8 */   public long getCompressedSize() { throw new RuntimeException("Stub!"); } 
/*  9 */   public long getCrc() { throw new RuntimeException("Stub!"); } 
/* 10 */   public byte[] getExtra() { throw new RuntimeException("Stub!"); } 
/* 11 */   public int getMethod() { throw new RuntimeException("Stub!"); } 
/* 12 */   public String getName() { throw new RuntimeException("Stub!"); } 
/* 13 */   public long getSize() { throw new RuntimeException("Stub!"); } 
/* 14 */   public long getTime() { throw new RuntimeException("Stub!"); } 
/* 15 */   public boolean isDirectory() { throw new RuntimeException("Stub!"); } 
/* 16 */   public void setComment(String comment) { throw new RuntimeException("Stub!"); } 
/* 17 */   public void setCompressedSize(long value) { throw new RuntimeException("Stub!"); } 
/* 18 */   public void setCrc(long value) { throw new RuntimeException("Stub!"); } 
/* 19 */   public void setExtra(byte[] data) { throw new RuntimeException("Stub!"); } 
/* 20 */   public void setMethod(int value) { throw new RuntimeException("Stub!"); } 
/* 21 */   public void setSize(long value) { throw new RuntimeException("Stub!"); } 
/* 22 */   public void setTime(long value) { throw new RuntimeException("Stub!"); } 
/* 23 */   public String toString() { throw new RuntimeException("Stub!"); } 
/* 24 */   public Object clone() { throw new RuntimeException("Stub!"); } 
/* 25 */   public int hashCode() { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.zip.ZipEntry
 * JD-Core Version:    0.6.0
 */