/*   */ package java.util.zip;
/*   */ 
/*   */ import java.io.IOException;
/*   */ 
/*   */ public class ZipException extends IOException
/*   */ {
/*   */   public ZipException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public ZipException(String detailMessage) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.zip.ZipException
 * JD-Core Version:    0.6.0
 */