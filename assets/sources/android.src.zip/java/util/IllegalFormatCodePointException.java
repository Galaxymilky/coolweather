/*   */ package java.util;
/*   */ 
/*   */ import java.io.Serializable;
/*   */ 
/*   */ public class IllegalFormatCodePointException extends IllegalFormatException
/*   */   implements Serializable
/*   */ {
/*   */   public IllegalFormatCodePointException(int c)
/*   */   {
/* 6 */     throw new RuntimeException("Stub!"); } 
/* 7 */   public int getCodePoint() { throw new RuntimeException("Stub!"); } 
/* 8 */   public String getMessage() { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.IllegalFormatCodePointException
 * JD-Core Version:    0.6.0
 */