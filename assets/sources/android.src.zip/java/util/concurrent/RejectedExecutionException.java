/*   */ package java.util.concurrent;
/*   */ 
/*   */ public class RejectedExecutionException extends RuntimeException
/*   */ {
/*   */   public RejectedExecutionException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public RejectedExecutionException(String message) { throw new RuntimeException("Stub!"); } 
/* 7 */   public RejectedExecutionException(String message, Throwable cause) { throw new RuntimeException("Stub!"); } 
/* 8 */   public RejectedExecutionException(Throwable cause) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.concurrent.RejectedExecutionException
 * JD-Core Version:    0.6.0
 */