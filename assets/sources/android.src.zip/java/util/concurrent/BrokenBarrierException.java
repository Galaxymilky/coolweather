/*   */ package java.util.concurrent;
/*   */ 
/*   */ public class BrokenBarrierException extends Exception
/*   */ {
/*   */   public BrokenBarrierException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public BrokenBarrierException(String message) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.concurrent.BrokenBarrierException
 * JD-Core Version:    0.6.0
 */