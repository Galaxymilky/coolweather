package java.util.concurrent;

public abstract interface ScheduledFuture<V> extends Delayed, Future<V>
{
}

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.concurrent.ScheduledFuture
 * JD-Core Version:    0.6.0
 */