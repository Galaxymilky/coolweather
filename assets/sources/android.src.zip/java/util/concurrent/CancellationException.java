/*   */ package java.util.concurrent;
/*   */ 
/*   */ public class CancellationException extends IllegalStateException
/*   */ {
/*   */   public CancellationException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public CancellationException(String message) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.concurrent.CancellationException
 * JD-Core Version:    0.6.0
 */