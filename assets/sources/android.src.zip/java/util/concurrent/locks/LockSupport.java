/*    */ package java.util.concurrent.locks;
/*    */ 
/*    */ public class LockSupport
/*    */ {
/*    */   LockSupport()
/*    */   {
/*  4 */     throw new RuntimeException("Stub!"); } 
/*  5 */   public static void unpark(Thread thread) { throw new RuntimeException("Stub!"); } 
/*  6 */   public static void park(Object blocker) { throw new RuntimeException("Stub!"); } 
/*  7 */   public static void parkNanos(Object blocker, long nanos) { throw new RuntimeException("Stub!"); } 
/*  8 */   public static void parkUntil(Object blocker, long deadline) { throw new RuntimeException("Stub!"); } 
/*  9 */   public static Object getBlocker(Thread t) { throw new RuntimeException("Stub!"); } 
/* 10 */   public static void park() { throw new RuntimeException("Stub!"); } 
/* 11 */   public static void parkNanos(long nanos) { throw new RuntimeException("Stub!"); } 
/* 12 */   public static void parkUntil(long deadline) { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.concurrent.locks.LockSupport
 * JD-Core Version:    0.6.0
 */