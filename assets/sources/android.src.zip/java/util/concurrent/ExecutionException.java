/*   */ package java.util.concurrent;
/*   */ 
/*   */ public class ExecutionException extends Exception
/*   */ {
/*   */   protected ExecutionException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   protected ExecutionException(String message) { throw new RuntimeException("Stub!"); } 
/* 7 */   public ExecutionException(String message, Throwable cause) { throw new RuntimeException("Stub!"); } 
/* 8 */   public ExecutionException(Throwable cause) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.concurrent.ExecutionException
 * JD-Core Version:    0.6.0
 */