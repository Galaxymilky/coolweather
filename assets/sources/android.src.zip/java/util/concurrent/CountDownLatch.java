/*   */ package java.util.concurrent;
/*   */ 
/*   */ public class CountDownLatch
/*   */ {
/*   */   public CountDownLatch(int count)
/*   */   {
/* 4 */     throw new RuntimeException("Stub!"); } 
/* 5 */   public void await() throws InterruptedException { throw new RuntimeException("Stub!"); } 
/* 6 */   public boolean await(long timeout, TimeUnit unit) throws InterruptedException { throw new RuntimeException("Stub!"); } 
/* 7 */   public void countDown() { throw new RuntimeException("Stub!"); } 
/* 8 */   public long getCount() { throw new RuntimeException("Stub!"); } 
/* 9 */   public String toString() { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.concurrent.CountDownLatch
 * JD-Core Version:    0.6.0
 */