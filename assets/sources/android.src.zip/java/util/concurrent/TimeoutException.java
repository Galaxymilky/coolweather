/*   */ package java.util.concurrent;
/*   */ 
/*   */ public class TimeoutException extends Exception
/*   */ {
/*   */   public TimeoutException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public TimeoutException(String message) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.concurrent.TimeoutException
 * JD-Core Version:    0.6.0
 */