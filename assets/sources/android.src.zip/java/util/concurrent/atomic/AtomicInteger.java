/*    */ package java.util.concurrent.atomic;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class AtomicInteger extends Number
/*    */   implements Serializable
/*    */ {
/*    */   public AtomicInteger(int initialValue)
/*    */   {
/*  6 */     throw new RuntimeException("Stub!"); } 
/*  7 */   public AtomicInteger() { throw new RuntimeException("Stub!"); } 
/*  8 */   public final int get() { throw new RuntimeException("Stub!"); } 
/*  9 */   public final void set(int newValue) { throw new RuntimeException("Stub!"); } 
/* 10 */   public final void lazySet(int newValue) { throw new RuntimeException("Stub!"); } 
/* 11 */   public final int getAndSet(int newValue) { throw new RuntimeException("Stub!"); } 
/* 12 */   public final boolean compareAndSet(int expect, int update) { throw new RuntimeException("Stub!"); } 
/* 13 */   public final boolean weakCompareAndSet(int expect, int update) { throw new RuntimeException("Stub!"); } 
/* 14 */   public final int getAndIncrement() { throw new RuntimeException("Stub!"); } 
/* 15 */   public final int getAndDecrement() { throw new RuntimeException("Stub!"); } 
/* 16 */   public final int getAndAdd(int delta) { throw new RuntimeException("Stub!"); } 
/* 17 */   public final int incrementAndGet() { throw new RuntimeException("Stub!"); } 
/* 18 */   public final int decrementAndGet() { throw new RuntimeException("Stub!"); } 
/* 19 */   public final int addAndGet(int delta) { throw new RuntimeException("Stub!"); } 
/* 20 */   public String toString() { throw new RuntimeException("Stub!"); } 
/* 21 */   public int intValue() { throw new RuntimeException("Stub!"); } 
/* 22 */   public long longValue() { throw new RuntimeException("Stub!"); } 
/* 23 */   public float floatValue() { throw new RuntimeException("Stub!"); } 
/* 24 */   public double doubleValue() { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.concurrent.atomic.AtomicInteger
 * JD-Core Version:    0.6.0
 */