/*    */ package java.util.concurrent.atomic;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class AtomicReference<V>
/*    */   implements Serializable
/*    */ {
/*    */   public AtomicReference(V initialValue)
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public AtomicReference() { throw new RuntimeException("Stub!"); } 
/*  7 */   public final V get() { throw new RuntimeException("Stub!"); } 
/*  8 */   public final void set(V newValue) { throw new RuntimeException("Stub!"); } 
/*  9 */   public final void lazySet(V newValue) { throw new RuntimeException("Stub!"); } 
/* 10 */   public final boolean compareAndSet(V expect, V update) { throw new RuntimeException("Stub!"); } 
/* 11 */   public final boolean weakCompareAndSet(V expect, V update) { throw new RuntimeException("Stub!"); } 
/* 12 */   public final V getAndSet(V newValue) { throw new RuntimeException("Stub!"); } 
/* 13 */   public String toString() { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.concurrent.atomic.AtomicReference
 * JD-Core Version:    0.6.0
 */