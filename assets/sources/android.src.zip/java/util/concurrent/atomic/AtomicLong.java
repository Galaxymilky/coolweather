/*    */ package java.util.concurrent.atomic;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class AtomicLong extends Number
/*    */   implements Serializable
/*    */ {
/*    */   public AtomicLong(long initialValue)
/*    */   {
/*  6 */     throw new RuntimeException("Stub!"); } 
/*  7 */   public AtomicLong() { throw new RuntimeException("Stub!"); } 
/*  8 */   public final long get() { throw new RuntimeException("Stub!"); } 
/*  9 */   public final void set(long newValue) { throw new RuntimeException("Stub!"); } 
/* 10 */   public final void lazySet(long newValue) { throw new RuntimeException("Stub!"); } 
/* 11 */   public final long getAndSet(long newValue) { throw new RuntimeException("Stub!"); } 
/* 12 */   public final boolean compareAndSet(long expect, long update) { throw new RuntimeException("Stub!"); } 
/* 13 */   public final boolean weakCompareAndSet(long expect, long update) { throw new RuntimeException("Stub!"); } 
/* 14 */   public final long getAndIncrement() { throw new RuntimeException("Stub!"); } 
/* 15 */   public final long getAndDecrement() { throw new RuntimeException("Stub!"); } 
/* 16 */   public final long getAndAdd(long delta) { throw new RuntimeException("Stub!"); } 
/* 17 */   public final long incrementAndGet() { throw new RuntimeException("Stub!"); } 
/* 18 */   public final long decrementAndGet() { throw new RuntimeException("Stub!"); } 
/* 19 */   public final long addAndGet(long delta) { throw new RuntimeException("Stub!"); } 
/* 20 */   public String toString() { throw new RuntimeException("Stub!"); } 
/* 21 */   public int intValue() { throw new RuntimeException("Stub!"); } 
/* 22 */   public long longValue() { throw new RuntimeException("Stub!"); } 
/* 23 */   public float floatValue() { throw new RuntimeException("Stub!"); } 
/* 24 */   public double doubleValue() { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.concurrent.atomic.AtomicLong
 * JD-Core Version:    0.6.0
 */