/*   */ package java.util.concurrent;
/*   */ 
/*   */ public class Exchanger<V>
/*   */ {
/*   */   public Exchanger()
/*   */   {
/* 4 */     throw new RuntimeException("Stub!"); } 
/* 5 */   public V exchange(V x) throws InterruptedException { throw new RuntimeException("Stub!"); } 
/* 6 */   public V exchange(V x, long timeout, TimeUnit unit) throws InterruptedException, TimeoutException { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.concurrent.Exchanger
 * JD-Core Version:    0.6.0
 */