/*    */ package java.util.concurrent;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.AbstractQueue;
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import java.util.Queue;
/*    */ 
/*    */ public class ConcurrentLinkedQueue<E> extends AbstractQueue<E>
/*    */   implements Queue<E>, Serializable
/*    */ {
/*    */   public ConcurrentLinkedQueue()
/*    */   {
/*  6 */     throw new RuntimeException("Stub!"); } 
/*  7 */   public ConcurrentLinkedQueue(Collection<? extends E> c) { throw new RuntimeException("Stub!"); } 
/*  8 */   public boolean add(E e) { throw new RuntimeException("Stub!"); } 
/*  9 */   public boolean offer(E e) { throw new RuntimeException("Stub!"); } 
/* 10 */   public E poll() { throw new RuntimeException("Stub!"); } 
/* 11 */   public E peek() { throw new RuntimeException("Stub!"); } 
/* 12 */   public boolean isEmpty() { throw new RuntimeException("Stub!"); } 
/* 13 */   public int size() { throw new RuntimeException("Stub!"); } 
/* 14 */   public boolean contains(Object o) { throw new RuntimeException("Stub!"); } 
/* 15 */   public boolean remove(Object o) { throw new RuntimeException("Stub!"); } 
/* 16 */   public boolean addAll(Collection<? extends E> c) { throw new RuntimeException("Stub!"); } 
/* 17 */   public Object[] toArray() { throw new RuntimeException("Stub!"); } 
/*    */   public <T> T[] toArray(T[] a) {
/* 19 */     throw new RuntimeException("Stub!"); } 
/* 20 */   public Iterator<E> iterator() { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.concurrent.ConcurrentLinkedQueue
 * JD-Core Version:    0.6.0
 */