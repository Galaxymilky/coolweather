package java.util.concurrent;

public abstract interface ThreadFactory
{
  public abstract Thread newThread(Runnable paramRunnable);
}

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.concurrent.ThreadFactory
 * JD-Core Version:    0.6.0
 */