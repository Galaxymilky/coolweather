package java.util.concurrent;

public abstract interface Executor
{
  public abstract void execute(Runnable paramRunnable);
}

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.concurrent.Executor
 * JD-Core Version:    0.6.0
 */