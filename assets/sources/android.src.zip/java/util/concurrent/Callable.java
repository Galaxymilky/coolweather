package java.util.concurrent;

public abstract interface Callable<V>
{
  public abstract V call()
    throws Exception;
}

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.concurrent.Callable
 * JD-Core Version:    0.6.0
 */