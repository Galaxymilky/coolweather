/*    */ package java.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public final class Currency
/*    */   implements Serializable
/*    */ {
/*    */   Currency()
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public static Currency getInstance(String currencyCode) { throw new RuntimeException("Stub!"); } 
/*  7 */   public static Currency getInstance(Locale locale) { throw new RuntimeException("Stub!"); } 
/*  8 */   public String getCurrencyCode() { throw new RuntimeException("Stub!"); } 
/*  9 */   public String getSymbol() { throw new RuntimeException("Stub!"); } 
/* 10 */   public String getSymbol(Locale locale) { throw new RuntimeException("Stub!"); } 
/* 11 */   public int getDefaultFractionDigits() { throw new RuntimeException("Stub!"); } 
/* 12 */   public String toString() { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.Currency
 * JD-Core Version:    0.6.0
 */