/*    */ package java.util;
/*    */ 
/*    */ public class WeakHashMap<K, V> extends AbstractMap<K, V>
/*    */   implements Map<K, V>
/*    */ {
/*    */   public WeakHashMap()
/*    */   {
/*  6 */     throw new RuntimeException("Stub!"); } 
/*  7 */   public WeakHashMap(int capacity) { throw new RuntimeException("Stub!"); } 
/*  8 */   public WeakHashMap(int capacity, float loadFactor) { throw new RuntimeException("Stub!"); } 
/*  9 */   public WeakHashMap(Map<? extends K, ? extends V> map) { throw new RuntimeException("Stub!"); } 
/* 10 */   public void clear() { throw new RuntimeException("Stub!"); } 
/* 11 */   public boolean containsKey(Object key) { throw new RuntimeException("Stub!"); } 
/* 12 */   public Set<Map.Entry<K, V>> entrySet() { throw new RuntimeException("Stub!"); } 
/* 13 */   public Set<K> keySet() { throw new RuntimeException("Stub!"); } 
/* 14 */   public Collection<V> values() { throw new RuntimeException("Stub!"); } 
/* 15 */   public V get(Object key) { throw new RuntimeException("Stub!"); } 
/* 16 */   public boolean containsValue(Object value) { throw new RuntimeException("Stub!"); } 
/* 17 */   public boolean isEmpty() { throw new RuntimeException("Stub!"); } 
/* 18 */   public V put(K key, V value) { throw new RuntimeException("Stub!"); } 
/* 19 */   public void putAll(Map<? extends K, ? extends V> map) { throw new RuntimeException("Stub!"); } 
/* 20 */   public V remove(Object key) { throw new RuntimeException("Stub!"); } 
/* 21 */   public int size() { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.util.WeakHashMap
 * JD-Core Version:    0.6.0
 */