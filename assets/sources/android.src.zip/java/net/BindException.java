/*   */ package java.net;
/*   */ 
/*   */ public class BindException extends SocketException
/*   */ {
/*   */   public BindException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public BindException(String detailMessage) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.net.BindException
 * JD-Core Version:    0.6.0
 */