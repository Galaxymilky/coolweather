/*   */ package java.net;
/*   */ 
/*   */ public final class PasswordAuthentication
/*   */ {
/*   */   public PasswordAuthentication(String userName, char[] password)
/*   */   {
/* 4 */     throw new RuntimeException("Stub!"); } 
/* 5 */   public char[] getPassword() { throw new RuntimeException("Stub!"); } 
/* 6 */   public String getUserName() { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.net.PasswordAuthentication
 * JD-Core Version:    0.6.0
 */