/*   */ package java.net;
/*   */ 
/*   */ import java.io.UnsupportedEncodingException;
/*   */ 
/*   */ public class URLDecoder
/*   */ {
/*   */   public URLDecoder()
/*   */   {
/* 4 */     throw new RuntimeException("Stub!"); } 
/* 6 */   @Deprecated
/*   */   public static String decode(String s) { throw new RuntimeException("Stub!"); } 
/* 7 */   public static String decode(String s, String encoding) throws UnsupportedEncodingException { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.net.URLDecoder
 * JD-Core Version:    0.6.0
 */