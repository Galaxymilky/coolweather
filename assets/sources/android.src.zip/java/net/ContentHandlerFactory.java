package java.net;

public abstract interface ContentHandlerFactory
{
  public abstract ContentHandler createContentHandler(String paramString);
}

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.net.ContentHandlerFactory
 * JD-Core Version:    0.6.0
 */