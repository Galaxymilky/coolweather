/*   */ package java.net;
/*   */ 
/*   */ public class ConnectException extends SocketException
/*   */ {
/*   */   public ConnectException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public ConnectException(String detailMessage) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.net.ConnectException
 * JD-Core Version:    0.6.0
 */