/*    */ package java.net;
/*    */ 
/*    */ public final class Inet4Address extends InetAddress
/*    */ {
/*    */   Inet4Address()
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public boolean isAnyLocalAddress() { throw new RuntimeException("Stub!"); } 
/*  7 */   public boolean isLinkLocalAddress() { throw new RuntimeException("Stub!"); } 
/*  8 */   public boolean isLoopbackAddress() { throw new RuntimeException("Stub!"); } 
/*  9 */   public boolean isMCGlobal() { throw new RuntimeException("Stub!"); } 
/* 10 */   public boolean isMCLinkLocal() { throw new RuntimeException("Stub!"); } 
/* 11 */   public boolean isMCNodeLocal() { throw new RuntimeException("Stub!"); } 
/* 12 */   public boolean isMCOrgLocal() { throw new RuntimeException("Stub!"); } 
/* 13 */   public boolean isMCSiteLocal() { throw new RuntimeException("Stub!"); } 
/* 14 */   public boolean isMulticastAddress() { throw new RuntimeException("Stub!"); } 
/* 15 */   public boolean isSiteLocalAddress() { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.net.Inet4Address
 * JD-Core Version:    0.6.0
 */