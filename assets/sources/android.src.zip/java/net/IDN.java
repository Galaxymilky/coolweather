/*   */ package java.net;
/*   */ 
/*   */ public final class IDN
/*   */ {
/*   */   public static final int ALLOW_UNASSIGNED = 1;
/*   */   public static final int USE_STD3_ASCII_RULES = 2;
/*   */ 
/*   */   IDN()
/*   */   {
/* 4 */     throw new RuntimeException("Stub!"); } 
/* 5 */   public static String toASCII(String input, int flags) { throw new RuntimeException("Stub!"); } 
/* 6 */   public static String toASCII(String input) { throw new RuntimeException("Stub!"); } 
/* 7 */   public static String toUnicode(String input, int flags) { throw new RuntimeException("Stub!"); } 
/* 8 */   public static String toUnicode(String input) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.net.IDN
 * JD-Core Version:    0.6.0
 */