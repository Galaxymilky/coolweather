package java.net;

public abstract interface FileNameMap
{
  public abstract String getContentTypeFor(String paramString);
}

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.net.FileNameMap
 * JD-Core Version:    0.6.0
 */