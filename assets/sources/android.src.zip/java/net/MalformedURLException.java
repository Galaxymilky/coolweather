/*   */ package java.net;
/*   */ 
/*   */ import java.io.IOException;
/*   */ 
/*   */ public class MalformedURLException extends IOException
/*   */ {
/*   */   public MalformedURLException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public MalformedURLException(String detailMessage) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.net.MalformedURLException
 * JD-Core Version:    0.6.0
 */