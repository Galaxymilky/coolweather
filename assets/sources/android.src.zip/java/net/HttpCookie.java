/*    */ package java.net;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public final class HttpCookie
/*    */   implements Cloneable
/*    */ {
/*    */   public HttpCookie(String name, String value)
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public static boolean domainMatches(String domainPattern, String host) { throw new RuntimeException("Stub!"); } 
/*  7 */   public static List<HttpCookie> parse(String header) { throw new RuntimeException("Stub!"); } 
/*  8 */   public String getComment() { throw new RuntimeException("Stub!"); } 
/*  9 */   public String getCommentURL() { throw new RuntimeException("Stub!"); } 
/* 10 */   public boolean getDiscard() { throw new RuntimeException("Stub!"); } 
/* 11 */   public String getDomain() { throw new RuntimeException("Stub!"); } 
/* 12 */   public long getMaxAge() { throw new RuntimeException("Stub!"); } 
/* 13 */   public String getName() { throw new RuntimeException("Stub!"); } 
/* 14 */   public String getPath() { throw new RuntimeException("Stub!"); } 
/* 15 */   public String getPortlist() { throw new RuntimeException("Stub!"); } 
/* 16 */   public boolean getSecure() { throw new RuntimeException("Stub!"); } 
/* 17 */   public String getValue() { throw new RuntimeException("Stub!"); } 
/* 18 */   public int getVersion() { throw new RuntimeException("Stub!"); } 
/* 19 */   public boolean hasExpired() { throw new RuntimeException("Stub!"); } 
/* 20 */   public void setComment(String comment) { throw new RuntimeException("Stub!"); } 
/* 21 */   public void setCommentURL(String commentURL) { throw new RuntimeException("Stub!"); } 
/* 22 */   public void setDiscard(boolean discard) { throw new RuntimeException("Stub!"); } 
/* 23 */   public void setDomain(String pattern) { throw new RuntimeException("Stub!"); } 
/* 24 */   public void setMaxAge(long deltaSeconds) { throw new RuntimeException("Stub!"); } 
/* 25 */   public void setPath(String path) { throw new RuntimeException("Stub!"); } 
/* 26 */   public void setPortlist(String portList) { throw new RuntimeException("Stub!"); } 
/* 27 */   public void setSecure(boolean secure) { throw new RuntimeException("Stub!"); } 
/* 28 */   public void setValue(String value) { throw new RuntimeException("Stub!"); } 
/* 29 */   public void setVersion(int v) { throw new RuntimeException("Stub!"); } 
/* 30 */   public Object clone() { throw new RuntimeException("Stub!"); } 
/* 31 */   public boolean equals(Object object) { throw new RuntimeException("Stub!"); } 
/* 32 */   public int hashCode() { throw new RuntimeException("Stub!"); } 
/* 33 */   public String toString() { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.net.HttpCookie
 * JD-Core Version:    0.6.0
 */