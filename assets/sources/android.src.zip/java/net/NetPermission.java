/*   */ package java.net;
/*   */ 
/*   */ import java.security.BasicPermission;
/*   */ import java.security.Permission;
/*   */ 
/*   */ public final class NetPermission extends BasicPermission
/*   */ {
/*   */   public NetPermission(String name)
/*   */   {
/* 5 */     super((String)null, (String)null); throw new RuntimeException("Stub!"); } 
/* 6 */   public NetPermission(String name, String actions) { super((String)null, (String)null); throw new RuntimeException("Stub!"); } 
/* 7 */   public String getActions() { throw new RuntimeException("Stub!"); } 
/* 8 */   public boolean implies(Permission permission) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.net.NetPermission
 * JD-Core Version:    0.6.0
 */