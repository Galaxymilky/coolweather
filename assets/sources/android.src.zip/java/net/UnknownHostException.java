/*   */ package java.net;
/*   */ 
/*   */ import java.io.IOException;
/*   */ 
/*   */ public class UnknownHostException extends IOException
/*   */ {
/*   */   public UnknownHostException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public UnknownHostException(String detailMessage) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.net.UnknownHostException
 * JD-Core Version:    0.6.0
 */