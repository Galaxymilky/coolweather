/*   */ package java.net;
/*   */ 
/*   */ import java.io.IOException;
/*   */ 
/*   */ public class UnknownServiceException extends IOException
/*   */ {
/*   */   public UnknownServiceException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public UnknownServiceException(String detailMessage) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.net.UnknownServiceException
 * JD-Core Version:    0.6.0
 */