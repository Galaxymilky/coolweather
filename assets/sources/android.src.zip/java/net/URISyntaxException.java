/*    */ package java.net;
/*    */ 
/*    */ public class URISyntaxException extends Exception
/*    */ {
/*    */   public URISyntaxException(String input, String reason, int index)
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public URISyntaxException(String input, String reason) { throw new RuntimeException("Stub!"); } 
/*  7 */   public int getIndex() { throw new RuntimeException("Stub!"); } 
/*  8 */   public String getReason() { throw new RuntimeException("Stub!"); } 
/*  9 */   public String getInput() { throw new RuntimeException("Stub!"); } 
/* 10 */   public String getMessage() { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.net.URISyntaxException
 * JD-Core Version:    0.6.0
 */