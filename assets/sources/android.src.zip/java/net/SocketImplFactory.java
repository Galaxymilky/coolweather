package java.net;

public abstract interface SocketImplFactory
{
  public abstract SocketImpl createSocketImpl();
}

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.net.SocketImplFactory
 * JD-Core Version:    0.6.0
 */