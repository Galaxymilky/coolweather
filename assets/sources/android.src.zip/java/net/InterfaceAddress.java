/*    */ package java.net;
/*    */ 
/*    */ public class InterfaceAddress
/*    */ {
/*    */   InterfaceAddress()
/*    */   {
/*  4 */     throw new RuntimeException("Stub!"); } 
/*  5 */   public boolean equals(Object obj) { throw new RuntimeException("Stub!"); } 
/*  6 */   public int hashCode() { throw new RuntimeException("Stub!"); } 
/*  7 */   public String toString() { throw new RuntimeException("Stub!"); } 
/*  8 */   public InetAddress getAddress() { throw new RuntimeException("Stub!"); } 
/*  9 */   public InetAddress getBroadcast() { throw new RuntimeException("Stub!"); } 
/* 10 */   public short getNetworkPrefixLength() { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.net.InterfaceAddress
 * JD-Core Version:    0.6.0
 */