/*    */ package java.net;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class CookieManager extends CookieHandler
/*    */ {
/*    */   public CookieManager()
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public CookieManager(CookieStore store, CookiePolicy cookiePolicy) { throw new RuntimeException("Stub!"); } 
/*  7 */   public Map<String, List<String>> get(URI uri, Map<String, List<String>> requestHeaders) throws IOException { throw new RuntimeException("Stub!"); } 
/*  8 */   public void put(URI uri, Map<String, List<String>> responseHeaders) throws IOException { throw new RuntimeException("Stub!"); } 
/*  9 */   public void setCookiePolicy(CookiePolicy cookiePolicy) { throw new RuntimeException("Stub!"); } 
/* 10 */   public CookieStore getCookieStore() { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.net.CookieManager
 * JD-Core Version:    0.6.0
 */