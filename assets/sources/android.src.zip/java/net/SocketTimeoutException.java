/*   */ package java.net;
/*   */ 
/*   */ import java.io.InterruptedIOException;
/*   */ 
/*   */ public class SocketTimeoutException extends InterruptedIOException
/*   */ {
/*   */   public SocketTimeoutException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public SocketTimeoutException(String detailMessage) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.net.SocketTimeoutException
 * JD-Core Version:    0.6.0
 */