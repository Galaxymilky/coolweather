package java.net;

public abstract interface URLStreamHandlerFactory
{
  public abstract URLStreamHandler createURLStreamHandler(String paramString);
}

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.net.URLStreamHandlerFactory
 * JD-Core Version:    0.6.0
 */