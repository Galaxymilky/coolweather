/*   */ package java.net;
/*   */ 
/*   */ public class PortUnreachableException extends SocketException
/*   */ {
/*   */   public PortUnreachableException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public PortUnreachableException(String detailMessage) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.net.PortUnreachableException
 * JD-Core Version:    0.6.0
 */