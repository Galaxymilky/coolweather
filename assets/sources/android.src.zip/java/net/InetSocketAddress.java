/*    */ package java.net;
/*    */ 
/*    */ public class InetSocketAddress extends SocketAddress
/*    */ {
/*    */   public InetSocketAddress(int port)
/*    */   {
/*  5 */     throw new RuntimeException("Stub!"); } 
/*  6 */   public InetSocketAddress(InetAddress address, int port) { throw new RuntimeException("Stub!"); } 
/*  7 */   public InetSocketAddress(String host, int port) { throw new RuntimeException("Stub!"); } 
/*  8 */   public static InetSocketAddress createUnresolved(String host, int port) { throw new RuntimeException("Stub!"); } 
/*  9 */   public final int getPort() { throw new RuntimeException("Stub!"); } 
/* 10 */   public final InetAddress getAddress() { throw new RuntimeException("Stub!"); } 
/* 11 */   public final String getHostName() { throw new RuntimeException("Stub!"); } 
/* 12 */   public final boolean isUnresolved() { throw new RuntimeException("Stub!"); } 
/* 13 */   public String toString() { throw new RuntimeException("Stub!"); } 
/* 14 */   public final boolean equals(Object socketAddr) { throw new RuntimeException("Stub!"); } 
/* 15 */   public final int hashCode() { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.net.InetSocketAddress
 * JD-Core Version:    0.6.0
 */