/*   */ package java.net;
/*   */ 
/*   */ import java.io.Serializable;
/*   */ 
/*   */ public abstract class SocketAddress
/*   */   implements Serializable
/*   */ {
/*   */   public SocketAddress()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.net.SocketAddress
 * JD-Core Version:    0.6.0
 */