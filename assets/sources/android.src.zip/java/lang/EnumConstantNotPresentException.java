/*   */ package java.lang;
/*   */ 
/*   */ public class EnumConstantNotPresentException extends RuntimeException
/*   */ {
/*   */   public EnumConstantNotPresentException(Class<? extends Enum> enumType, String constantName)
/*   */   {
/* 6 */     throw new RuntimeException("Stub!");
/*   */   }
/* 8 */   public Class<? extends Enum> enumType() { throw new RuntimeException("Stub!"); } 
/* 9 */   public String constantName() { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.lang.EnumConstantNotPresentException
 * JD-Core Version:    0.6.0
 */