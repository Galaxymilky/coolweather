/*   */ package java.lang;
/*   */ 
/*   */ public class IllegalArgumentException extends RuntimeException
/*   */ {
/*   */   public IllegalArgumentException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public IllegalArgumentException(String detailMessage) { throw new RuntimeException("Stub!"); } 
/* 7 */   public IllegalArgumentException(String message, Throwable cause) { throw new RuntimeException("Stub!"); } 
/* 8 */   public IllegalArgumentException(Throwable cause) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.lang.IllegalArgumentException
 * JD-Core Version:    0.6.0
 */