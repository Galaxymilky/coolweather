/*   */ package java.lang;
/*   */ 
/*   */ public class InternalError extends VirtualMachineError
/*   */ {
/*   */   public InternalError()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public InternalError(String detailMessage) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.lang.InternalError
 * JD-Core Version:    0.6.0
 */