/*   */ package java.lang;
/*   */ 
/*   */ public class IllegalAccessException extends Exception
/*   */ {
/*   */   public IllegalAccessException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public IllegalAccessException(String detailMessage) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.lang.IllegalAccessException
 * JD-Core Version:    0.6.0
 */