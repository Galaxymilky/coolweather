/*   */ package java.lang.reflect;
/*   */ 
/*   */ public class MalformedParameterizedTypeException extends RuntimeException
/*   */ {
/*   */   public MalformedParameterizedTypeException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.lang.reflect.MalformedParameterizedTypeException
 * JD-Core Version:    0.6.0
 */