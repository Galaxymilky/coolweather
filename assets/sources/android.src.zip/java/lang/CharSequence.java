package java.lang;

public abstract interface CharSequence
{
  public abstract int length();

  public abstract char charAt(int paramInt);

  public abstract CharSequence subSequence(int paramInt1, int paramInt2);

  public abstract String toString();
}

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.lang.CharSequence
 * JD-Core Version:    0.6.0
 */