/*   */ package java.lang;
/*   */ 
/*   */ public class IllegalMonitorStateException extends RuntimeException
/*   */ {
/*   */   public IllegalMonitorStateException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public IllegalMonitorStateException(String detailMessage) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.lang.IllegalMonitorStateException
 * JD-Core Version:    0.6.0
 */