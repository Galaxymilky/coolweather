/*   */ package java.lang;
/*   */ 
/*   */ public class VerifyError extends LinkageError
/*   */ {
/*   */   public VerifyError()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public VerifyError(String detailMessage) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.lang.VerifyError
 * JD-Core Version:    0.6.0
 */