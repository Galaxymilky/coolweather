/*   */ package java.lang;
/*   */ 
/*   */ public class ArrayIndexOutOfBoundsException extends IndexOutOfBoundsException
/*   */ {
/*   */   public ArrayIndexOutOfBoundsException()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public ArrayIndexOutOfBoundsException(int index) { throw new RuntimeException("Stub!"); } 
/* 7 */   public ArrayIndexOutOfBoundsException(String detailMessage) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.lang.ArrayIndexOutOfBoundsException
 * JD-Core Version:    0.6.0
 */