/*   */ package java.lang;
/*   */ 
/*   */ public class InstantiationError extends IncompatibleClassChangeError
/*   */ {
/*   */   public InstantiationError()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public InstantiationError(String detailMessage) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.lang.InstantiationError
 * JD-Core Version:    0.6.0
 */