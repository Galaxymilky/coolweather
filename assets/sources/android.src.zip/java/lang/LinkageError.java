/*   */ package java.lang;
/*   */ 
/*   */ public class LinkageError extends Error
/*   */ {
/*   */   public LinkageError()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public LinkageError(String detailMessage) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.lang.LinkageError
 * JD-Core Version:    0.6.0
 */