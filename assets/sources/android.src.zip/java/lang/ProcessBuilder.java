/*    */ package java.lang;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public final class ProcessBuilder
/*    */ {
/*    */   public ProcessBuilder(String[] command)
/*    */   {
/*  4 */     throw new RuntimeException("Stub!"); } 
/*  5 */   public ProcessBuilder(List<String> command) { throw new RuntimeException("Stub!"); } 
/*  6 */   public List<String> command() { throw new RuntimeException("Stub!"); } 
/*  7 */   public ProcessBuilder command(String[] command) { throw new RuntimeException("Stub!"); } 
/*  8 */   public ProcessBuilder command(List<String> command) { throw new RuntimeException("Stub!"); } 
/*  9 */   public File directory() { throw new RuntimeException("Stub!"); } 
/* 10 */   public ProcessBuilder directory(File directory) { throw new RuntimeException("Stub!"); } 
/* 11 */   public Map<String, String> environment() { throw new RuntimeException("Stub!"); } 
/* 12 */   public boolean redirectErrorStream() { throw new RuntimeException("Stub!"); } 
/* 13 */   public ProcessBuilder redirectErrorStream(boolean redirectErrorStream) { throw new RuntimeException("Stub!"); } 
/* 14 */   public Process start() throws IOException { throw new RuntimeException("Stub!");
/*    */   }
/*    */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.lang.ProcessBuilder
 * JD-Core Version:    0.6.0
 */