/*   */ package java.lang;
/*   */ 
/*   */ public class Exception extends Throwable
/*   */ {
/*   */   public Exception()
/*   */   {
/* 5 */     throw new RuntimeException("Stub!"); } 
/* 6 */   public Exception(String detailMessage) { throw new RuntimeException("Stub!"); } 
/* 7 */   public Exception(String detailMessage, Throwable throwable) { throw new RuntimeException("Stub!"); } 
/* 8 */   public Exception(Throwable throwable) { throw new RuntimeException("Stub!");
/*   */   }
/*   */ }

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.lang.Exception
 * JD-Core Version:    0.6.0
 */