package java.lang;

public abstract interface Comparable<T>
{
  public abstract int compareTo(T paramT);
}

/* Location:           C:\Users\dynamicniu\Desktop\android.jar
 * Qualified Name:     java.lang.Comparable
 * JD-Core Version:    0.6.0
 */